content = r"""
% ======================================================================
\section{Módulo 6: Sistemas Operativos en Tiempo Real (FreeRTOS)}

\subsection{Paradigma Super-Loop (Bare-Metal) vs RTOS}
En sistemas embebidos existen dos enfoques arquitectónicos fundamentales:
\begin{enumerate}
    \item \textbf{El Paradigma Super-Loop (Bucle Infinito Tradicional):}
    Consiste en una función principal \texttt{while(1)} que ejecuta funciones de forma secuencial y atiende eventos mediante flags activadas en interrupciones (ISRs).
    \begin{itemize}
        \item \textit{Reglas de Oro del Super-Loop:}
        \begin{enumerate}
            \item \textbf{No ser Bloqueantes:} Ninguna función puede contener bucles de espera activa (\texttt{while(!(SPI->SR \& TXE));}) ni demoras artificiales (\texttt{delay\_ms()}).
            \item \textbf{Ejecución Ultrarrápida:} Cada función debe ejecutar una porción mínima de código y retornar de inmediato.
            \item \textbf{Descomposición en Máquinas de Estado Finitas (FSM):} Las tareas complejas deben dividirse en múltiples estados.
            \item \textbf{Reentrancia:} Las funciones compartidas entre el bucle principal y las ISRs deben ser puramente reentrantes (no usar variables estáticas globales sin protección).
        \end{enumerate}
        \item \textit{Limitación Fatal:} A medida que el sistema crece, el tiempo de ciclo del bucle se vuelve altamente variable (\textbf{Jitter excesivo}), imposibilitando garantizar tiempos de respuesta deterministas a eventos concurrentes.
    \end{itemize}
    \item \textbf{El Paradigma RTOS (Real-Time Operating System):}
    Divide la aplicación en múltiples \textbf{Tareas (Tasks)} concurrentes e independientes. El núcleo (\textit{Kernel}) incluye un \textbf{Planificador (Scheduler)} que decide qué tarea utiliza la CPU en cada instante en base a prioridades y eventos, garantizando determinismo temporal.
\end{enumerate}

\subsection{Conceptos de Tiempo Real: Hard vs Soft Real-Time}
\begin{conceptbox}{Hard Real-Time vs Soft Real-Time}
Un sistema de Tiempo Real no es aquel que opera a máxima velocidad ("lo más rápido posible"), sino aquel cuyo **comportamiento temporal es estrictamente determinista y predecible**:
\begin{itemize}
    \item \textbf{Hard Real-Time (Tiempo Real Estricto):} El cumplimiento de los plazos temporales (\textit{deadlines}) es una restricción funcional absoluta. Si una respuesta llega tarde (incluso por microsegundos), se considera un \textbf{fallo catastrófico del sistema}, con riesgo de pérdidas de vidas o daños severos (ej. disparo de Airbag en choque en $< 20$ ms, frenos ABS, control de vuelo de un misil, marcapasos).
    \item \textbf{Soft Real-Time (Tiempo Real Blando):} El incumplimiento ocasional de un plazo degrada la calidad del servicio percibida, pero el sistema continúa funcionando de forma segura sin colapsar (ej. actualización de pantalla LCD, streaming de audio/video, adquisición de datos climáticos).
\end{itemize}
\end{conceptbox}

\subsection{Arquitectura, Tipos de Datos y Notación Húngara en FreeRTOS}
FreeRTOS es altamente portable y define sus propios tipos de datos independientes del compilador:
\begin{itemize}
    \item \texttt{TickType\_t}: Conteo de interrupciones de reloj del kernel (típicamente entero de 32 bits sin signo).
    \item \texttt{BaseType\_t}: Tipo de dato más eficiente y natural para la arquitectura del microcontrolador (en ARM Cortex-M3 es un \texttt{long} / \texttt{int32\_t} de 32 bits con signo).
\end{itemize}

\begin{conceptbox}{Notación Húngara de Convención en FreeRTOS}
\begin{itemize}
    \item \textbf{Prefijos en Variables:}
    \begin{itemize}
        \item \texttt{c}: \texttt{char} (ej. \texttt{cBuffer})
        \item \texttt{s}: \texttt{short} (16 bits)
        \item \texttt{l}: \texttt{long} (32 bits)
        \item \texttt{x}: \texttt{BaseType\_t}, estructuras y handles de FreeRTOS (ej. \texttt{xQueueHandle})
        \item \texttt{u}: \texttt{unsigned} (modificador sin signo, ej. \texttt{uxPriority}, \texttt{ulTimerCount})
        \item \texttt{p}: Puntero (ej. \texttt{pxHigherPriorityTaskWoken}, \texttt{pvParameters})
    \end{itemize}
    \item \textbf{Prefijos en Funciones:} Indican el tipo de retorno y el archivo fuente donde están definidas:
    \begin{itemize}
        \item \texttt{vTask...}: Función que retorna \texttt{void}, definida en \texttt{tasks.c}.
        \item \texttt{xQueue...}: Función que retorna un \texttt{BaseType\_t}, definida en \texttt{queue.c}.
        \item \texttt{prv...}: Función privada (\textit{static}) dentro de su archivo fuente.
    \end{itemize}
    \item \textbf{Prefijos en Macros:}
    \begin{itemize}
        \item \texttt{pd...}: Definición genérica de FreeRTOS (ej. \texttt{pdTRUE = 1}, \texttt{pdFALSE = 0}, \texttt{pdPASS = 1}).
        \item \texttt{err...}: Códigos de error (ej. \texttt{errQUEUE\_FULL = 0}).
        \item \texttt{port...}: Definiciones específicas de la arquitectura hardware (ej. \texttt{portMAX\_DELAY}).
    \end{itemize}
\end{itemize}
\end{conceptbox}

\subsection{Gestión de Tareas (Task Management)}
En FreeRTOS, una tarea es un hilo de ejecución independiente con su propia pila (\textit{Stack}) y un bloque de control (\textit{Task Control Block - TCB}) que almacena su estado y prioridad.

\begin{conceptbox}{Anatomía y Creación de una Tarea}
Una función de tarea debe tener el siguiente prototipo estricto y \textbf{NUNCA debe retornar} mediante la instrucción \texttt{return}:
\begin{lstlisting}
void vMiTarea(void *pvParameters)
{
    // Inicializacion local de la tarea
    for(;;)
    {
        // Codigo de ejecucion periodica o dirigida por eventos
        vTaskDelay(pdMS_TO_TICKS(100)); // Cede la CPU bloqueandose 100ms
    }
    // Si alguna vez sale del bucle, debe autoeliminarse obligatoriamente:
    vTaskDelete(NULL);
}
\end{lstlisting}

\textbf{Creación con la API \texttt{xTaskCreate()}:}
\begin{lstlisting}
BaseType_t xTaskCreate(
    TaskFunction_t pxTaskCode,      // Puntero a la funcion de la tarea (ej. vMiTarea)
    const char * const pcName,      // Nombre descriptivo de texto (para debug)
    const configSTACK_DEPTH_TYPE usStackDepth, // Tamano del Stack en PALABRAS de 32 bits (128 = 512 bytes)
    void * const pvParameters,      // Puntero generico de parametros pasado a la tarea
    UBaseType_t uxPriority,         // Prioridad (0 = Idle / minima, configMAX_PRIORITIES-1 = maxima)
    TaskHandle_t * const pxCreatedTask // Puntero para guardar el Handler de la tarea
);
\end{lstlisting}
\end{conceptbox}

\begin{conceptbox}{Máquina de Estados de una Tarea (FSM de 4 Estados)}
\begin{enumerate}
    \item \textbf{Running (En Ejecución):} La tarea está siendo ejecutada actualmente por el núcleo de la CPU. En procesadores de un solo núcleo, **solo una tarea** puede estar en estado Running en cada instante.
    \item \textbf{Ready (Lista):} Tareas que tienen todo lo necesario para ejecutarse pero están esperando que el Scheduler les asigne la CPU porque actualmente corre otra tarea de igual o mayor prioridad.
    \item \textbf{Blocked (Bloqueada):} La tarea está esperando un evento temporal (ej. transcurso de un delay con \texttt{vTaskDelay()}) o un evento de sincronización (llegada de un dato a una Cola, liberación de un Semáforo o Mutex). **NO consume absolutamente ningún ciclo de CPU.**
    \item \textbf{Suspended (Suspendida):} La tarea fue detenida explícitamente mediante la función \texttt{vTaskSuspend()}. Solo puede reanudarse si otra tarea o ISR invoca \texttt{vTaskResume()}.
\end{enumerate}
\end{conceptbox}

\subsection{El Planificador (Scheduler) y Algoritmo de Selección}
FreeRTOS utiliza un \textbf{Planificador Preemptivo por Prioridades con Time-Slicing}:
\begin{itemize}
    \item \textbf{Preemptivo por Prioridades:} En todo momento, el Scheduler garantiza que la CPU ejecute la tarea de mayor prioridad que se encuentre en estado **Ready**. Si una tarea de mayor prioridad se desbloquea, desaloja inmediatamente (\textit{preempts}) a la tarea de menor prioridad en ejecución.
    \item \textbf{Time-Slicing (Round-Robin):} Si existen múltiples tareas en estado Ready con exactamente la misma prioridad, el kernel comparte el tiempo de CPU entre ellas asignando un \textit{quantum} de tiempo (1 Tick de SysTick) a cada una alternativamente.
    \item \textbf{Inanición (Starvation):} Ocurre cuando una tarea de alta prioridad se mantiene en estado Ready de forma permanente (ej. bucle infinito sin funciones de bloqueo \texttt{vTaskDelay} o colas), impidiendo que las tareas de menor prioridad se ejecuten jamás.
    \item \textbf{Algoritmo Optimizado por Puerto (\texttt{configUSE\_PORT\_OPTIMISED\_TASK\_SELECTION = 1}):} En ARM Cortex-M3, el kernel utiliza la instrucción en lenguaje máquina **\texttt{CLZ} (Count Leading Zeros)** para evaluar el mapa de bits de prioridades en **tiempo constante $O(1)$ (un solo ciclo de reloj)**, eliminando la necesidad de recorrer listas enlazadas en C.
\end{itemize}

\subsection{Temporización: vTaskDelay() vs vTaskDelayUntil()}
\begin{center}
\small
\begin{tabularx}{\textwidth}{@{}p{3.2cm}XX@{}}
\toprule
\textbf{Característica} & \textbf{vTaskDelay(xTicksToDelay)} & \textbf{vTaskDelayUntil(\&xLastWakeTime, xPeriod)} \\
\midrule
\textbf{Tipo de Retardo} & \textbf{Relativo:} El retardo de $N$ ticks se cuenta a partir del instante en que se invoca la función. & \textbf{Absoluto:} Calcula el tiempo de desbloqueo respecto al inicio del período anterior. \\
\rowcolor{hdrgray} \textbf{Deriva Temporal (Drift)} & \textbf{SÍ produce deriva acumulativa (\textit{jitter}):} El período real total es $\text{Tiempo de Ejecución} + \text{Delay}$, desfasándose en el tiempo. & \textbf{NO produce deriva (\textit{Drift-Free}):} Garantiza una frecuencia de ejecución periódica fija y exacta. \\
\textbf{Uso Recomendado} & Tareas esporádicas, parpadeo simple de LEDs no críticos, timeouts de reintento. & Muestreo de sensores en lazos de control (\textit{PID}), lectura de encoders, generación de señales periódicas. \\
\bottomrule
\end{tabularx}
\end{center}

\subsection{La Tarea Idle y la Función Idle Hook}
La tarea \textbf{Idle} es creada automáticamente por el kernel al iniciar el Scheduler (\texttt{vTaskStartScheduler()}) con la **prioridad más baja posible (Prioridad 0)**.
\begin{enumerate}
    \item \textbf{Responsabilidades de la Tarea Idle:}
    \begin{itemize}
        \item Garantizar que siempre exista al menos una tarea en estado Ready para que la CPU nunca quede flotante sin instrucciones que ejecutar.
        \item **Liberar la memoria dinámica** (Stack y TCB asignados por el Heap) de aquellas tareas que hayan sido eliminadas mediante la función \texttt{vTaskDelete()}.
    \end{itemize}
    \item \textbf{La Función \texttt{vApplicationIdleHook()}:}
    Si la macro \texttt{configUSE\_IDLE\_HOOK} está en 1, el kernel invoca automáticamente esta función en cada ciclo de la tarea Idle.
    \begin{itemize}
        \item \textit{Usos típicos:} Poner el microcontrolador en modo de bajo consumo (\texttt{\_\_WFI()} - Wait For Interrupt) o refrescar el perro guardián (\textit{Watchdog}).
        \item \textit{Regla de Oro Indispensable:} **ESTÁ TERMINANTEMENTE PROHIBIDO que \texttt{vApplicationIdleHook()} se bloquee, demore o invoque funciones con timeout (ej. \texttt{vTaskDelay})**, ya que si la tarea Idle se bloquea, el kernel colapsa y no se puede liberar memoria.
    \end{itemize}
\end{enumerate}

\subsection{Mecanismos de Comunicación: Colas de Mensajes (Queues)}
Las Colas son el mecanismo primario de comunicación segura (\textit{Thread-Safe}) entre tareas y entre interrupciones y tareas.

\begin{conceptbox}{Almacenamiento por "Copia por Valor" (Deep Copy)}
FreeRTOS almacena los datos en las colas copiando la información byte a byte (\textit{Pass by Value}) en lugar de solo copiar una referencia o puntero.
\begin{itemize}
    \item \textbf{Ventajas:}
    \begin{enumerate}
        \item \textbf{Desacoplamiento Total:} El emisor puede reutilizar o sobreescribir su variable local inmediatamente después de llamar a \texttt{xQueueSend()} sin temor a corromper los datos del receptor.
        \item \textbf{Seguridad con Variables Locales del Stack:} Permite enviar variables locales asignadas en la pila de una función sin riesgo de que la función retorne y libere la memoria antes de que el receptor la lea.
    \end{enumerate}
    \item \textbf{Paso de Punteros para Datos Grandes ($> 64$ bytes):} Si el dato es grande, copiar byte a byte consume mucho tiempo. En ese caso, se encola por valor el **puntero a la estructura** (\texttt{MiStruct\_t *pMsg}).
    \begin{itemize}
        \item \textit{Reglas de Seguridad Obligatorias al Enviar Punteros:}
        \begin{enumerate}
            \item \textbf{Transferencia Estricta de Propiedad (\textit{Ownership Handover}):} Una vez enviado el puntero, el emisor tiene terminantemente prohibido volver a acceder o modificar el buffer.
            \item \textbf{Memoria Dinámica Persistente:} El buffer apuntado debe residir en el Heap (\texttt{pvPortMalloc()}) o en variables globales, nunca en el stack local de una función efímera.
            \item \textbf{Liberación de Memoria:} El receptor es el responsable exclusivo de liberar la memoria dinámica (\texttt{vPortFree()}) una vez procesado el mensaje.
        \end{enumerate}
    \end{itemize}
\end{itemize}
\end{conceptbox}

\begin{conceptbox}{Funciones Principales de la API de Colas}
\begin{itemize}
    \item \texttt{QueueHandle\_t xQueueCreate(uxQueueLength, uxItemSize)}: Crea una cola en el Heap para $N$ elementos de tamaño $M$ bytes.
    \item \texttt{BaseType\_t xQueueSendToBack(xQueue, pvItem, xTicksToWait)}: Envía al final (FIFO). Si la cola está llena, la tarea se bloquea hasta \texttt{xTicksToWait} (usar \texttt{portMAX\_DELAY} para esperar indefinidamente).
    \item \texttt{BaseType\_t xQueueReceive(xQueue, pvBuffer, xTicksToWait)}: Lee y extrae el primer elemento de la cola. Si está vacía, la tarea se bloquea hasta \texttt{xTicksToWait}.
    \item \texttt{UBaseType\_t uxQueueMessagesWaiting(xQueue)}: Retorna la cantidad de elementos sin leer.
\end{itemize}
\end{conceptbox}

\subsection{Gestión de Interrupciones en FreeRTOS y Procesamiento Diferido}
\begin{conceptbox}{El API Seguro para Interrupciones (...FromISR) y pxHigherPriorityTaskWoken}
Las rutinas de servicio de interrupción (ISRs) de hardware **NO tienen contexto de tarea** y por ende **NUNCA pueden bloquearse**. FreeRTOS proporciona una versión especial de sus funciones de API con el sufijo \texttt{...FromISR}.

\textbf{El Parámetro \texttt{pxHigherPriorityTaskWoken}:}
\begin{enumerate}
    \item Se pasa la dirección de una variable inicializada en \texttt{pdFALSE}: \texttt{BaseType\_t xHigherPriorityTaskWoken = pdFALSE;}.
    \item Si al enviar un dato a una cola o entregar un semáforo desde la ISR se desbloquea una tarea que tiene una prioridad mayor a la tarea que fue interrumpida, la función \texttt{...FromISR} cambia automáticamente la variable a \texttt{pdTRUE}.
    \item Al final de la ISR, se invoca la macro \textbf{\texttt{portYIELD\_FROM\_ISR(xHigherPriorityTaskWoken)}}. Si la bandera es \texttt{pdTRUE}, el procesador solicita la excepción \texttt{PendSV} para que, al retornar de la ISR, la CPU ejecute de inmediato la tarea de alta prioridad recién desbloqueada sin esperar al próximo Tick del SysTick.
\end{enumerate}
\end{conceptbox}

\begin{conceptbox}{Patrón de Procesamiento Diferido (Deferred Interrupt Processing)}
\textbf{Problema:} Mantener una ISR ejecutando código prolongado (formateo de texto, cálculos complejos, escrituras lentas) bloquea otras interrupciones, aumenta el jitter del sistema y degrada el determinismo.

\textbf{Solución en Dos Mitades (Top-Half / Bottom-Half):}
\begin{enumerate}
    \item \textbf{Top-Half (La ISR de Hardware):} Es ultracorta (típicamente microsegundos). Lee el registro de datos del periférico, limpia la bandera de interrupción, entrega un \textbf{Semáforo Binario} mediante \texttt{xSemaphoreGiveFromISR()} y fuerza el cambio de contexto con \texttt{portYIELD\_FROM\_ISR()}.
    \item \textbf{Bottom-Half (Tarea Servidora en FreeRTOS):} Una tarea de alta prioridad permanece bloqueada esperando el semáforo (\texttt{xSemaphoreTake(xSem, portMAX\_DELAY)}). Al liberarse el semáforo, la tarea se despierta inmediatamente y ejecuta todo el procesamiento pesado de datos a nivel de hilo (Thread Mode), permitiendo que nuevas interrupciones de hardware se sigan atendiendo sin retrasos.
\end{enumerate}
\end{conceptbox}
"""
