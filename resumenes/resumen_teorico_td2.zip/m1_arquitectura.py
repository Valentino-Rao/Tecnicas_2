content = r"""
% ======================================================================
\section{Módulo 1: Arquitectura de Computadores, Rendimiento y Hardware/Software}

\subsection{Sistemas Embebidos vs Computación General}
Un \textbf{Sistema Embebido} es un sistema computacional diseñado para realizar una o pocas funciones dedicadas, frecuentemente dentro de un sistema mecánico o eléctrico mayor. El software forma una unidad indisoluble con el hardware.

\begin{conceptbox}{Restricciones Fundamentales de Diseño en Sistemas Embebidos}
\begin{enumerate}
    \item \textbf{Costo Extremo:} Producidos en tiradas de cientos de miles o millones de unidades. Cada centavo de dólar en el microcontrolador, memorias o pasivos impacta directamente en la viabilidad económica del producto.
    \item \textbf{Consumo de Potencia y Energía:} Crítico en dispositivos alimentados a batería (sensores remotos, wearables) y en entornos industriales cerrados con refrigeración puramente pasiva (sin ventiladores).
    \item \textbf{Confiabilidad, Disponibilidad y Seguridad Funcional (Safety-Critical):} En sistemas críticos (frenos ABS, control de aviónica, marcapasos, control de inyección automotriz), un fallo del sistema puede ocasionar catástrofes humanas o pérdidas millonarias.
    \item \textbf{Determinismo Temporal y Tiempo Real (Real-Time):} Capacidad de responder a estímulos físicos del entorno garantizando un tiempo de respuesta acotado y predecible (deadline).
\end{enumerate}
\end{conceptbox}

\subsection{Unidades de Almacenamiento: Estándar Decimal (SI) vs Binario (IEC 80000-13)}
Históricamente existió ambigüedad entre las unidades de base 10 (fabricantes de discos) y de base 2 (diseñadores de memoria y software). La norma IEC 80000-13 formalizó los prefijos binarios:

\begin{center}
\small
\begin{tabularx}{\textwidth}{@{}llccclX@{}}
\toprule
\textbf{Prefijo SI} & \textbf{Símb.} & \textbf{Valor Base 10} & \textbf{Prefijo IEC} & \textbf{Símb.} & \textbf{Valor Base 2} & \textbf{Diferencia} \\
\midrule
Kilobyte & KB & $10^3 = 1.000$ B & Kibibyte & KiB & $2^{10} = 1.024$ B & $+2,4\%$ \\
Megabyte & MB & $10^6 = 1.000.000$ B & Mebibyte & MiB & $2^{20} = 1.048.576$ B & $+4,86\%$ \\
Gigabyte & GB & $10^9 = 10^9$ B & Gibibyte & GiB & $2^{30} = 1.073.741.824$ B & $+7,37\%$ \\
Terabyte & TB & $10^{12} = 10^{12}$ B & Tebibyte & TiB & $2^{40} = 1.099.511.627.776$ B & $+9,95\%$ \\
\bottomrule
\end{tabularx}
\end{center}

\textit{Importancia en TD2:} Una memoria Flash de 64 KiB en el STM32F103 posee exactamente $64 \times 1.024 = 65.536$ bytes, direccionables mediante 16 líneas de dirección ($2^{16} = 65.536$).

\subsection{Las 8 Grandes Ideas de la Arquitectura de Computadores}
Formuladas por David Patterson y John Hennessy, constituyen los pilares del diseño digital moderno:
\begin{enumerate}
    \item \textbf{Diseño para la Ley de Moore:} Como el ciclo de diseño dura de 2 a 4 años, se debe proyectar el chip para la tecnología que existirá al momento de fabricación, no la del inicio.
    \item \textbf{Uso de la Abstracción para Simplificar el Diseño:} Ocultar detalles de bajo nivel mediante capas (Hardware $\rightarrow$ Microarquitectura $\rightarrow$ ISA $\rightarrow$ OS/Drivers $\rightarrow$ Aplicación).
    \item \textbf{Hacer el Caso Común Rápido (Make the Common Case Fast):} Optimizar las operaciones que ocurren con mayor frecuencia (ej. instrucciones simples en RISC).
    \item \textbf{Rendimiento Mediante Paralelismo:} Ejecutar múltiples operaciones simultáneamente (multiprocesadores, multicore).
    \item \textbf{Rendimiento Mediante Segmentación (Pipelining):} Solapar etapas de ejecución de distintas instrucciones (Fetch, Decode, Execute).
    \item \textbf{Rendimiento Mediante Predicción:} Anticipar el flujo de ejecución (ej. Branch Prediction).
    \item \textbf{Jerarquía de Memorias:} Combinar memorias pequeñas y ultrarrápidas (Registros, Caché) con memorias más grandes y lentas (SRAM, Flash, Disco).
    \item \textbf{Confiabilidad Mediante Redundancia:} Incluir componentes de respaldo (ECC en memoria, paridad, watchdog) para tolerar fallos.
\end{enumerate}

\subsection{La Interfaz Hardware/Software: ISA y ABI}
\begin{itemize}
    \item \textbf{ISA (Instruction Set Architecture):} Contrato abstracto entre el hardware y el software. Define el conjunto de instrucciones de máquina, registros visibles, modos de direccionamiento, modelo de memoria y excepciones. Permite que múltiples implementaciones físicas (ej. Cortex-M3, Cortex-M4, Apple Silicon) ejecuten el mismo código binario.
    \item \textbf{Microarquitectura:} Implementación física concreta de la ISA en silicio (tamaño de pipeline, buses internos, unidades funcionales ALU/Multiplicador).
    \item \textbf{ABI (Application Binary Interface):} Reglas a nivel binario para que módulos compilados por separado interactúen (convenciones de llamada, pasaje de parámetros en registros R0-R3, alineación de stack). En ARM se utiliza el estándar \textbf{AAPCS} (ARM Architecture Procedure Call Standard).
\end{itemize}

\subsection{Ecuación Fundamental del Rendimiento de CPU}
El rendimiento de un sistema se evalúa mediante el tiempo de ejecución de un programa:

\begin{formulabox}{Ecuación de Tiempo de CPU}
$$\text{Tiempo de CPU} = \text{Instrucciones del Programa (IC)} \times \text{CPI} \times T_{\text{clock}} = \frac{\text{IC} \times \text{CPI}}{f_{\text{clock}}}$$
donde:
\begin{itemize}
    \item $\text{IC}$ (Instruction Count): Cantidad total de instrucciones ejecutadas por el programa. Depende del algoritmo, compilador e ISA.
    \item $\text{CPI}$ (Cycles Per Instruction): Promedio de ciclos de reloj necesarios para ejecutar una instrucción. Depende de la microarquitectura y la ISA.
    \item $T_{\text{clock}} = \frac{1}{f_{\text{clock}}}$: Período de la señal de reloj del procesador. Depende de la tecnología de fabricación y la lógica del chip.
\end{itemize}
$$\text{CPI Ponderado} = \sum_{i=1}^{n} (\text{CPI}_i \times f_i) = \frac{\sum (\text{CPI}_i \times \text{Count}_i)}{\text{IC}}$$
\end{formulabox}

\subsection{El Muro de Potencia (Power Wall) y la Ley de Amdahl}
Durante décadas, la frecuencia de reloj creció exponencialmente gracias al escalamiento de Dennard. Hacia 2006, la industria se topó con el \textbf{Muro de Potencia}, imposibilitando seguir aumentando los GHz en un solo núcleo.

\begin{formulabox}{Potencia Dinámica en CMOS y Ley de Amdahl}
$$P_{\text{din}} = \frac{1}{2} \cdot C_{\text{carga}} \cdot V_{DD}^2 \cdot f_{\text{clock}} \cdot \alpha$$
donde $C$ es la capacitancia parásita, $V_{DD}$ la tensión de alimentación, $f$ la frecuencia y $\alpha$ el factor de actividad.

\textbf{Límites Físicos:}
\begin{enumerate}
    \item \textbf{Límite de Voltaje:} Reducir $V_{DD}$ por debajo de $\sim 0.8$V dispara las corrientes de fuga (\textit{leakage currents}) y el ruido cuántico.
    \item \textbf{Límite Térmico:} La densidad de potencia superó los 100 W/cm$^2$ (densidad térmica de la tobera de un cohete), requiriendo soluciones de disipación inviables.
\end{enumerate}
\textbf{Solución de la Industria:} Giro hacia procesadores \textbf{Multi-núcleo (Multicore)} a frecuencias moderadas.

\textbf{Ley de Amdahl (Límite del Aceleramiento Paralelo):}
$$S_{\text{total}} = \frac{1}{(1 - F) + \frac{F}{S}}$$
donde $F$ es la fracción del código paralelizable y $S$ el factor de aceleración de esa fracción. Si el 20\% del código es puramente secuencial ($F=0,8$), el aceleramiento máximo teórico con infinitos núcleos es $\frac{1}{1-0,8} = 5\times$.
\end{formulabox}
"""
