content = r"""
% ======================================================================
\section{Módulo 8: Actividades y Ejercicios Extraídos de la Bibliografía Oficial}

En esta sección se compilan los ejercicios y problemas de estudio extraídos directamente de los libros de texto de referencia utilizados por la cátedra en cada unidad temática.

\subsection{Fuente 1: Patterson \& Hennessy --- \textit{Computer Organization and Design (ARM Edition)}}

\begin{conceptbox}{Problema P\&H 1.12: Falacias de Rendimiento y Frecuencia de Reloj (Capítulo 1)}
Considere dos procesadores $P_1$ y $P_2$ ejecutando dos variantes del mismo algoritmo:
\begin{itemize}
    \item \textbf{Procesador $P_1$:} Frecuencia $f_1 = 4\text{ GHz}$, $\text{CPI}_1 = 0,9$, requiere ejecutar $\text{IC}_1 = 5,0 \times 10^9$ instrucciones.
    \item \textbf{Procesador $P_2$:} Frecuencia $f_2 = 3\text{ GHz}$, $\text{CPI}_2 = 0,75$, requiere ejecutar $\text{IC}_2 = 1,0 \times 10^9$ instrucciones.
\end{itemize}
\begin{enumerate}
    \item[a)] \textit{¿Es verdadero que el procesador con mayor frecuencia de reloj ($P_1$) tiene siempre un mayor rendimiento? Calcule el tiempo de CPU para ambos.}
    \item[b)] \textit{Si un nuevo compilador optimiza el código de $P_1$ reduciendo sus instrucciones a $1,0 \times 10^9$ manteniendo su $\text{CPI}_1 = 0,9$, ¿cuál procesador es más rápido y por qué factor?}
\end{enumerate}
\end{conceptbox}

\begin{conceptbox}{Problema P\&H 1.14: Ecuación de Rendimiento y Mezcla de Instrucciones (Capítulo 1)}
Un programa ejecuta la siguiente mezcla de instrucciones en un procesador con frecuencia de reloj $f = 2\text{ GHz}$:
\begin{itemize}
    \item $50 \times 10^6$ instrucciones de Punto Flotante (FP) con $\text{CPI}_{\text{FP}} = 1$.
    \item $110 \times 10^6$ instrucciones Enteras (INT) con $\text{CPI}_{\text{INT}} = 1$.
    \item $80 \times 10^6$ instrucciones de Carga/Almacenamiento (L/S) con $\text{CPI}_{\text{L/S}} = 4$.
    \item $16 \times 10^6$ instrucciones de Salto (Branch) con $\text{CPI}_{\text{Branch}} = 2$.
\end{itemize}
\begin{enumerate}
    \item[a)] \textit{Calcule el CPI ponderado promedio del programa y el tiempo total de ejecución de CPU.}
    \item[b)] \textit{¿En cuánto debe mejorarse el CPI de las instrucciones FP si se desea que el programa ejecute 2 veces más rápido (reducción del 50\% en tiempo)? ¿Es físicamente posible?}
    \item[c)] \textit{¿En cuánto debe mejorarse el CPI de las instrucciones L/S si se desea duplicar el rendimiento global del programa?}
    \item[d)] \textit{¿En cuánto mejora el tiempo de ejecución si se optimiza el procesador reduciendo el CPI de INT y FP en un 40\% y el CPI de L/S y Branch en un 30\%?}
\end{enumerate}
\end{conceptbox}

\begin{conceptbox}{Problema P\&H 1.15: Ley de Amdahl y Overhead en Multiprocesamiento (Capítulo 1)}
Un programa requiere $t = 100\text{ s}$ de ejecución secuencial en 1 solo procesador. Al adaptarse para ejecutar en un sistema con $p$ procesadores, el tiempo de cálculo paralelo se divide como $t/p$, pero se introducen $4\text{ s}$ fijos de sobrecarga (\textit{overhead}) por sincronización y secciones críticas, independientemente del número de procesadores.
\begin{enumerate}
    \item[a)] \textit{Calcule el tiempo de ejecución y el factor de aceleración ($S$) para $p = 2, 4, 8, 16$ y $64$ procesadores.}
    \item[b)] \textit{¿Cuál es el límite máximo teórico de aceleración que se puede alcanzar con infinitos procesadores ($p \rightarrow \infty$)?}
\end{enumerate}
\end{conceptbox}

\begin{conceptbox}{Problema P\&H 2.12: Flujo de Compilación y Resolución de Símbolos en Enlazado (Capítulo 2)}
Explique cómo el enlazador (\textit{Linker}) resuelve las referencias a funciones externas y constantes:
\begin{enumerate}
    \item[a)] \textit{¿Qué información contiene la Tabla de Símbolos (\textit{Symbol Table}) y la Tabla de Reubicación (\textit{Relocation Table}) emitidas por el ensamblador en un archivo objeto relocable ELF?}
    \item[b)] \textit{¿Por qué una instrucción de salto relativo (\texttt{B etiqueta}) requiere reubicación durante el enlazado si el destino se encuentra en otro archivo fuente compilado por separado?}
\end{enumerate}
\end{conceptbox}

\subsection{Fuente 2: Harris \& Harris --- \textit{Digital Design and Computer Architecture (ARM Edition)}}

\begin{conceptbox}{Problema H\&H 6.1: Principios de Diseño en la Arquitectura ARM (Capítulo 6)}
Demuestre cómo la arquitectura ARM aplica los cuatro principios clásicos de diseño de computadores:
\begin{enumerate}
    \item[a)] \textit{La regularidad favorece la simplicidad (Regularity supports simplicity).}
    \item[b)] \textit{Hacer el caso común rápido (Make the common case fast).}
    \item[c)] \textit{Menor es más rápido (Smaller is faster).}
    \item[d)] \textit{Un buen diseño exige buenos compromisos (Good design demands good compromises).}
\end{enumerate}
\end{conceptbox}

\begin{conceptbox}{Problema H\&H 6.3 \& 6.4: Direccionamiento por Bytes vs Palabras de 32 bits (Capítulo 6)}
En una memoria direccionable por bytes (\textit{byte-addressable}) con arquitectura de 32 bits:
\begin{enumerate}
    \item[a)] \textit{¿Cuál es la dirección en bytes de la palabra de memoria número 42 (\textit{Word 42})?}
    \item[b)] \textit{¿Cuáles son las direcciones en bytes de los 4 bytes individuales que integran la palabra 42?}
    \item[c)] \textit{¿Por qué una lectura de palabra de 32 bits no alineada (ej. en la dirección \texttt{0x0000\_002B}) degrada el rendimiento o genera un fallo de alineación en arquitecturas RISC estrictas?}
\end{enumerate}
\end{conceptbox}

\begin{conceptbox}{Problema H\&H 6.5 \& 6.8: Detección de Endianness y Almacenamiento Little-Endian (Capítulo 6)}
Considere la variable de 32 bits \texttt{uint32\_t dato = 0x12345678;} almacenada en la dirección de memoria \texttt{0x2000\_0000}.
\begin{enumerate}
    \item[a)] \textit{Muestre el contenido byte a byte en las direcciones \texttt{0x2000\_0000}, \texttt{0x2000\_0001}, \texttt{0x2000\_0002} y \texttt{0x2000\_0003} en una arquitectura Little-Endian (ARM Cortex-M3) vs Big-Endian.}
    \item[b)] \textit{Analice el siguiente código en C y explique por qué permite detectar en tiempo de ejecución si el procesador es Little-Endian o Big-Endian:}
\begin{lstlisting}
uint32_t test = 1;
char *p = (char *)&test;
if (*p == 1) { /* Little-Endian */ } else { /* Big-Endian */ }
\end{lstlisting}
\end{enumerate}
\end{conceptbox}

\begin{conceptbox}{Problema H\&H 6.27: Estándar de Llamadas AAPCS y Preservación de Registros (Capítulo 6)}
En el estándar ARM Architecture Procedure Call Standard (AAPCS):
\begin{enumerate}
    \item[a)] \textit{¿Qué registros deben ser preservados obligatoriamente por la función invocada (\textit{Callee-Saved}) antes de modificar sus valores?}
    \item[b)] \textit{¿Qué registros son considerados efímeros (\textit{Caller-Saved}) y pueden ser sobreescritos libremente por una función?}
    \item[c)] \textit{¿Por qué este estándar determinó la selección de los 8 registros apilados automáticamente por hardware en el Cortex-M3 al ingresar a una interrupción?}
\end{enumerate}
\end{conceptbox}

\begin{conceptbox}{Problema H\&H 9.1 \& 9.2: Memory-Mapped I/O y Decodificación de Direcciones (Capítulo 9)}
\begin{enumerate}
    \item[a)] \textit{Diseñe conceptualmente el decodificador de direcciones necesario para mapear un periférico de salida de 32 bits (registro de control de LEDs) en el rango de direcciones \texttt{0x4001\_0800} a \texttt{0x4001\_080F}.}
    \item[b)] \textit{Explique la diferencia entre Polling (espera activa), Interrupciones y DMA (Direct Memory Access) para transferir un bloque de 1 KB desde un receptor UART hacia la memoria RAM, comparando el impacto en la ocupación de la CPU.}
\end{enumerate}
\end{conceptbox}

\subsection{Fuente 3: Joseph Yiu --- \textit{The Definitive Guide to ARM Cortex-M3 and Cortex-M4}}

\begin{conceptbox}{Problema Yiu 7.1: Configuración de Prioridades de Grupo y Desalojo en el NVIC (Capítulo 7)}
En un microcontrolador STM32F103 con 4 bits de prioridad implementados:
\begin{itemize}
    \item Se configura \texttt{PRIGROUP = 0b100} (2 bits para Preemption Priority y 2 bits para Sub-priority).
    \item Interrupción A (Timer): Preemption Priority $= 1$, Sub-priority $= 2$.
    \item Interrupción B (USART): Preemption Priority $= 2$, Sub-priority $= 0$.
    \item Interrupción C (EXTI): Preemption Priority $= 1$, Sub-priority $= 0$.
\end{itemize}
\begin{enumerate}
    \item[a)] \textit{Si la Interrupción B se está ejecutando en la CPU y ocurre el evento de la Interrupción A, ¿la Interrupción A desaloja a B? Justifique.}
    \item[b)] \textit{Si la Interrupción A se está ejecutando y ocurre la Interrupción C, ¿la Interrupción C desaloja a A? Justifique.}
    \item[c)] \textit{Si la CPU está en Thread Mode y ocurren simultáneamente A y C, ¿cuál se atiende primero y por qué?}
\end{enumerate}
\end{conceptbox}

\begin{conceptbox}{Problema Yiu 7.3: Cálculo de Ahorro de Ciclos con Tail-Chaining (Capítulo 7)}
Considere que la entrada a una interrupción (\textit{Stacking + Vector Fetch}) toma 12 ciclos de reloj y la salida (\textit{Unstacking}) toma 12 ciclos de reloj.
\begin{enumerate}
    \item[a)] \textit{¿Cuántos ciclos de reloj toma atender secuencialmente dos interrupciones pendientes $ISR_1$ e $ISR_2$ en una arquitectura tradicional sin Tail-Chaining?}
    \item[b)] \textit{¿Cuántos ciclos toma en ARM Cortex-M3 utilizando la optimización de Tail-Chaining (6 ciclos de transición entre handlers)? ¿Cuál es el porcentaje de ahorro en sobrecarga de CPU?}
\end{enumerate}
\end{conceptbox}

\subsection{Fuente 4: Richard Barry --- \textit{Mastering the FreeRTOS Real Time Kernel}}

\begin{conceptbox}{Problema FreeRTOS 3.1: Planificación Preemptiva e Inanición (Capítulo 3)}
Considere un sistema con tres tareas:
\begin{itemize}
    \item Tarea 1: Prioridad 3 (Alta), ejecuta un cálculo que dura 5 ms pero contiene un bucle infinito sin llamadas a \texttt{vTaskDelay()} ni bloqueo en colas.
    \item Tarea 2: Prioridad 2 (Media), ejecuta una máquina de estados periódica.
    \item Tarea 3: Prioridad 1 (Baja), procesa eventos de teclado.
\end{itemize}
\begin{enumerate}
    \item[a)] \textit{Describa el comportamiento del Scheduler. ¿Llegan a ejecutarse las Tareas 2 y 3? ¿Cómo se denomina este fenómeno?}
    \item[b)] \textit{Modifique la estructura de la Tarea 1 para garantizar que el sistema sea determinista y permita la ejecución de las tareas de menor prioridad.}
\end{enumerate}
\end{conceptbox}

\begin{conceptbox}{Problema FreeRTOS 4.2: Dimensionamiento de Colas y Copia por Valor (Capítulo 4)}
\begin{enumerate}
    \item[a)] \textit{Si se define una estructura \texttt{Telemetria\_t} (con campos \texttt{uint32\_t sensorID}, \texttt{float valor} y \texttt{uint32\_t timestamp}) y se crea una cola de 10 elementos mediante \texttt{xQueueCreate(10, sizeof(Telemetria\_t))}, ¿cuántos bytes de memoria RAM reserva FreeRTOS en el Heap para el buffer de datos de la cola?}
    \item[b)] \textit{Explique por qué si una tarea emisora envía una variable local asignada en su stack (\texttt{Telemetria\_t datosLocales; xQueueSend(q, \&datosLocales, 0);}), los datos recibidos por otra tarea son 100\% válidos incluso si la tarea emisora sale inmediatamente de su bloque de código.}
\end{enumerate}
\end{conceptbox}
"""
