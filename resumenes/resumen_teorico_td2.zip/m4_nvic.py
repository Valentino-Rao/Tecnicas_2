content = r"""
% ======================================================================
\section{Módulo 4: Controlador de Interrupciones y Excepciones (NVIC)}

\subsection{Concepto y Clasificación de Excepciones}
Una \textbf{Excepción} es cualquier evento que altera el flujo secuencial normal de instrucciones de la CPU. En la arquitectura ARMv7-M, las interrupciones de periféricos son un subconjunto de las excepciones del sistema.

\begin{center}
\small
\begin{tabularx}{\textwidth}{@{}llllX@{}}
\toprule
\textbf{Excepción / IRQ} & \textbf{Posición} & \textbf{Offset} & \textbf{Prioridad} & \textbf{Descripción y Causa de Disparo} \\
\midrule
\texttt{Initial SP} & 0 & \texttt{0x00} & -- & Valor cargado en MSP al resetear (\texttt{\_estack}). \\
\rowcolor{hdrgray} \texttt{Reset} & 1 & \texttt{0x04} & -3 (Fija) & Encendido (\textit{Power-On}) o botón de Reset. Salta a \texttt{Reset\_Handler}. \\
\texttt{NMI} & 2 & \texttt{0x08} & -2 (Fija) & Non-Maskable Interrupt. Eventos críticos (CSS: fallo de oscilador). \\
\rowcolor{hdrgray} \texttt{HardFault} & 3 & \texttt{0x0C} & -1 (Fija) & Fallo genérico e irrecuperable de hardware o escalamiento de otro fallo. \\
\texttt{MemManage} & 4 & \texttt{0x10} & Programable & Violación de permisos de memoria definidos por la MPU. \\
\rowcolor{hdrgray} \texttt{BusFault} & 5 & \texttt{0x14} & Programable & Error en el bus de datos o instrucciones (ej. acceso a dirección inválida). \\
\texttt{UsageFault} & 6 & \texttt{0x18} & Programable & Intento de ejecutar instrucción inválida, división por cero o $T=0$. \\
\rowcolor{hdrgray} \texttt{SVCall} & 11 & \texttt{0x2C} & Programable & Supervisor Call. Disparada por la instrucción \texttt{SVC} (usada por RTOS). \\
\texttt{PendSV} & 14 & \texttt{0x38} & Programable & Pendable Service Call. Excepción para cambio de contexto en RTOS. \\
\rowcolor{hdrgray} \texttt{SysTick} & 15 & \texttt{0x3C} & Programable & Interrupción periódica del temporizador del núcleo (Tick del kernel). \\
\texttt{IRQ0 -- IRQ67} & 16 a 83 & \texttt{0x40+} & Programable & Interrupciones de periféricos externos (EXTI, ADC, TIM, USART, etc.). \\
\bottomrule
\end{tabularx}
\end{center}

\subsection{La Tabla de Vectores y Reubicación Dinámica (VTOR)}
La tabla de vectores es un arreglo de punteros de 32 bits a funciones (\textit{ISR Handlers}).
\begin{itemize}
    \item Por defecto, tras el Reset reside en la dirección \texttt{0x0000\_0000} (o \texttt{0x0800\_0000} en Flash).
    \item \textbf{Bit 0 de cada puntero en 1:} Dado que Cortex-M3 solo soporta el juego Thumb, la dirección de cada Handler debe tener su bit menos significativo en 1 para que el salto no apague el bit T del registro EPSR.
    \item \textbf{Reubicación con VTOR (\texttt{SCB->VTOR}):} El registro \textit{Vector Table Offset Register} permite reubicar la tabla a cualquier dirección alineada (por ejemplo a la RAM en \texttt{0x2000\_0000}). Esto es fundamental en \textbf{Bootloaders} que cargan aplicaciones nuevas en memoria.
\end{itemize}

\subsection{Esquema de Prioridades del NVIC: Grupo vs Sub-prioridad}
Cortex-M3 define registros de prioridad de 8 bits para cada interrupción, pero los fabricantes implementan solo los bits más significativos. El STM32F103 implementa los **4 bits superiores** (\texttt{[7:4]}), ofreciendo **16 niveles de prioridad programables (0 a 15)**, donde el valor numérico **0 representa la MÁXIMA prioridad** y 15 la mínima.

\begin{conceptbox}{Preemption Priority (Grupo) vs Sub-prioridad (PRIGROUP)}
El campo de 4 bits se subdivide mediante el registro de configuración \texttt{SCB->AIRCR} (campo \texttt{PRIGROUP}) en dos partes:
\begin{enumerate}
    \item \textbf{Pre-emption Priority (Prioridad de Grupo / Desalojo):} Define si una interrupción entrante puede **interrumpir y desalojar (anidarse)** a una ISR que ya se está ejecutando en la CPU. Una interrupción solo puede desalojar a otra si su número de Pre-emption Priority es estrictamente MENOR.
    \item \textbf{Sub-priority (Sub-prioridad):} Define el orden de atención cuando dos interrupciones del mismo grupo se disparan **simultáneamente**. Una menor subprioridad NO puede desalojar a una ISR que ya comenzó a ejecutarse del mismo grupo.
\end{enumerate}
\end{conceptbox}

\subsection{Mecanismo de Auto-Stacking por Hardware y EXC\_RETURN}
A diferencia de arquitecturas tradicionales donde el programador debe salvar registros en ensamblador con instrucciones \texttt{PUSH} y \texttt{POP}, el Cortex-M3 realiza el apilamiento de forma **totalmente automática por hardware**:

\begin{center}
\small
\begin{tabularx}{\textwidth}{@{}llX@{}}
\toprule
\textbf{Paso} & \textbf{Acción del Hardware} & \textbf{Detalle Técnico} \\
\midrule
\textbf{1. Entrada a Excepción} & Auto-Stacking de 8 Registros (32 bytes) & El hardware empuja en el Stack activo (MSP o PSP): \texttt{R0, R1, R2, R3, R12, LR, PC, xPSR} en exactamente 12 ciclos de reloj. Son los registros \textit{caller-saved} según el estándar AAPCS de ARM. \\
\rowcolor{hdrgray} \textbf{2. Vector Fetch en Paralelo} & Búsqueda del Handler & Mientras el bus de datos apila los registros, el bus de instrucciones lee la dirección del handler de la Tabla de Vectores. \\
\textbf{3. Carga de EXC\_RETURN} & Carga en el registro LR & El hardware sobrescribe el registro \texttt{LR} con un valor especial mágico con patrón \texttt{0xFFFFFFFx}. \\
\rowcolor{hdrgray} \textbf{4. Retorno de Excepción} & Instrucción \texttt{BX LR} & Al finalizar la ISR, la instrucción \texttt{bx lr} intenta saltar a la dirección \texttt{0xFFFFFFFx}. El hardware intercepta este patrón y dispara la desapilación automática de los 8 registros restaurando el contexto previo. \\
\bottomrule
\end{tabularx}
\end{center}

\begin{conceptbox}{Valores Clave de EXC\_RETURN}
\begin{itemize}
    \item \texttt{0xFFFFFFF1}: Retorno a \textbf{Handler Mode}, utilizando el \textbf{MSP}. (Ocurre en interrupciones anidadas).
    \item \texttt{0xFFFFFFF9}: Retorno a \textbf{Thread Mode}, utilizando el \textbf{MSP}. (Común en programas Bare-Metal sin RTOS).
    \item \texttt{0xFFFFFFFD}: Retorno a \textbf{Thread Mode}, utilizando el \textbf{PSP}. (Común al retornar a una tarea de usuario en un RTOS).
\end{itemize}
\end{conceptbox}

\subsection{Optimizaciones de Latencia del NVIC}
\begin{enumerate}
    \item \textbf{Tail-Chaining (Encadenamiento de Cola):} Si al finalizar una ISR existe otra interrupción pendiente de igual o menor prioridad, la CPU **NO desapila los 8 registros para volverlos a apilar**. Salta directamente al nuevo handler en solo **6 ciclos de reloj** (ahorrando más de 24 ciclos).
    \item \textbf{Late Arrival (Llegada Tardía):} Si durante la secuencia de apilamiento para una interrupción de baja prioridad se dispara una de mayor prioridad, la CPU completa el apilamiento y atiende directamente a la de mayor prioridad sin reiniciar el proceso.
    \item \textbf{Pop Preemption (Desalojo en Desapilamiento):} Si durante la secuencia de desapilamiento de retorno llega una interrupción de mayor prioridad, el hardware aborta el desapilamiento y transfiere el control al nuevo handler de inmediato.
\end{enumerate}

\subsection{Registros de Enmascaramiento Global del Núcleo}
\begin{itemize}
    \item \textbf{PRIMASK (1 bit):} Al ponerse en 1 (\texttt{cpsid i}), eleva el nivel de prioridad de ejecución de la CPU a 0. Deshabilita todas las interrupciones configurables, permitiendo únicamente \texttt{NMI} y \texttt{HardFault}.
    \item \textbf{FAULTMASK (1 bit):} Al ponerse en 1 (\texttt{cpsid f}), eleva el nivel de prioridad a -1. Deshabilita todo excepto \texttt{NMI}.
    \item \textbf{BASEPRI (8 bits):} Registro de enmascaramiento por umbral. Deshabilita todas las interrupciones con prioridad numéricamente igual o mayor a su valor (menor prioridad), permitiendo que interrupciones críticas sigan ejecutándose. Es el mecanismo utilizado por FreeRTOS para sus \textbf{Secciones Críticas} (\texttt{configMAX\_SYSCALL\_INTERRUPT\_PRIORITY}).
\end{itemize}

\subsection{El Controlador de Interrupciones Externas (EXTI) y Mapeo AFIO}
El STM32 posee 16 líneas de interrupción externa independientes (\texttt{EXTI0} a \texttt{EXTI15}) conectadas a los pines GPIO:
\begin{itemize}
    \item Cada línea \texttt{EXTIn} puede conectarse al pin $n$ de cualquiera de los puertos (PA$n$, PB$n$, PC$n$, etc.) mediante los registros \texttt{AFIO->EXTICR[0..3]}.
    \item \textbf{Restricción:} No se pueden usar simultáneamente dos pines con el mismo número (ej. PA0 y PB0 no pueden generar EXTI0 a la vez).
    \item \textbf{Registros EXTI:}
    \begin{itemize}
        \item \texttt{EXTI->IMR}: Interrupt Mask Register (1 = desenmascara/habilita la interrupción).
        \item \texttt{EXTI->RTSR}: Rising Trigger Selection (1 = habilita disparo por flanco ascendente).
        \item \texttt{EXTI->FTSR}: Falling Trigger Selection (1 = habilita disparo por flanco descendente).
        \item \texttt{EXTI->PR}: Pending Register (1 = interrupción ocurrida. \textbf{Se limpia escribiendo un 1}).
    \end{itemize}
\end{itemize}
"""
