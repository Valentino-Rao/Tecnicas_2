# -*- coding: utf-8 -*-
content = r"""
% ======================================================================
\section{Módulo 7: Banco de 30 Preguntas Típicas de Examen Teórico con Respuestas Modelo}

\begin{examqbox}{1}
\textbf{¿Qué establece la Ley de Moore y cuáles fueron sus consecuencias técnicas y económicas directas?}
\vspace{1.5mm}

\textbf{Respuesta:}
Enunciada por Gordon Moore en 1965, establece que \textit{el número de transistores integrados en un circuito integrado se duplica aproximadamente cada 18 a 24 meses}.

\textbf{Consecuencias Directas:}
\begin{enumerate}
    \item \textbf{Económica (Costo por Transistor):} Al duplicarse la densidad con costos de oblea similares, el costo por transistor cayó de forma exponencial, permitiendo la masificación de computadoras, teléfonos celulares y sistemas embebidos de bajo costo.
    \item \textbf{Técnica (Velocidad y Consumo):} La reducción del tamaño de canal y de las capacidades parásitas permitió aumentar drásticamente la frecuencia de reloj y la integración de periféricos complejos (SoC).
\end{enumerate}
\end{examqbox}

\begin{examqbox}{2}
\textbf{¿Cuáles son las cuatro restricciones fundamentales de diseño que diferencian a los Sistemas Embebidos de las PCs y Servidores?}
\vspace{1.5mm}

\textbf{Respuesta:}
\begin{enumerate}
    \item \textbf{Costo Extremo:} Producidos en grandes volúmenes donde centavos de dólar deciden la viabilidad del producto.
    \item \textbf{Consumo de Potencia y Energía:} Crítico para autonomía en baterías y para operar sin ventiladores mecánicos.
    \item \textbf{Confiabilidad y Seguridad Funcional:} Un fallo puede ocasionar desastres económicos o pérdida de vidas humanas (aviónica, automotriz, médico).
    \item \textbf{Determinismo Temporal (Real-Time):} Obligación de responder a eventos externos dentro de límites temporales estrictos garantizados (\textit{deadlines}).
\end{enumerate}
\end{examqbox}

\begin{examqbox}{3}
\textbf{Explique la diferencia entre Kilobyte (KB) y Kibibyte (KiB) según la norma IEC 80000-13 y por qué es crítico en arquitectura de memoria.}
\vspace{1.5mm}

\textbf{Respuesta:}
\begin{itemize}
    \item \textbf{Kilobyte (KB):} Unidad decimal basada en potencias de 10 ($1\text{ KB} = 10^3 = 1.000\text{ bytes}$).
    \item \textbf{Kibibyte (KiB):} Unidad binaria formalizada por IEC ($1\text{ KiB} = 2^{10} = 1.024\text{ bytes}$).
\end{itemize}
\textbf{Importancia en Arquitectura:} El hardware digital decodifica memoria mediante líneas de dirección binarias ($2^N$). Un microcontrolador con bus de 16 líneas decodifica exactamente $2^{16} = 65.536\text{ bytes} = 64\text{ KiB}$, lo que difiere en un $+2,4\%$ respecto a $64.000\text{ bytes}$ ($64\text{ KB}$). A medida que la memoria crece (GiB vs GB), la discrepancia supera el $7\%$, siendo crítico para dimensionar buffers y tablas de paginación.
\end{examqbox}

\begin{examqbox}{4}
\textbf{Describa las 8 grandes ideas de la arquitectura de computadores según Patterson y Hennessy.}
\vspace{1.5mm}

\textbf{Respuesta:}
\begin{enumerate}
    \item \textbf{Diseño para la Ley de Moore:} Proyectar el diseño para la tecnología del año de fabricación.
    \item \textbf{Uso de la Abstracción:} Jerarquía de capas para ocultar detalles de bajo nivel.
    \item \textbf{Hacer el caso común rápido:} Optimizar las instrucciones de mayor frecuencia de uso.
    \item \textbf{Rendimiento mediante Paralelismo:} Procesamiento simultáneo de datos e instrucciones.
    \item \textbf{Rendimiento mediante Segmentación (Pipelining):} Solapar etapas de instrucciones.
    \item \textbf{Rendimiento mediante Predicción:} Anticipar ramas y accesos a memoria.
    \item \textbf{Jerarquía de Memorias:} Combinar memoria rápida pequeña con memoria lenta grande.
    \item \textbf{Confiabilidad mediante Redundancia:} Tolerancia a fallos con componentes de respaldo.
\end{enumerate}
\end{examqbox}

\begin{examqbox}{5}
\textbf{¿Qué es una ISA (Instruction Set Architecture) y por qué garantiza la independencia de implementación?}
\vspace{1.5mm}

\textbf{Respuesta:}
La \textbf{ISA} es la interfaz abstracta que especifica las instrucciones de máquina, registros visibles, modos de direccionamiento y manejo de excepciones de un procesador. 

Garantiza la independencia de implementación porque desacopla el qué (la especificación lógica) del cómo (la microarquitectura física). Permite que el mismo binario ejecute en silicios con microarquitecturas radicalmente distintas (ej. Cortex-M3 vs Cortex-M4 o procesadores multinúcleo) preservando la compatibilidad de software.
\end{examqbox}

\begin{examqbox}{6}
\textbf{Deduzca la ecuación de tiempo de CPU y explique cómo impactan el Compilador, la ISA y la Tecnología de Silicio en sus tres variables.}
\vspace{1.5mm}

\textbf{Respuesta:}
$$\text{Tiempo de CPU} = \text{IC} \times \text{CPI} \times T_{\text{clock}} = \frac{\text{IC} \times \text{CPI}}{f_{\text{clock}}}$$
\begin{itemize}
    \item \textbf{Compilador:} Impacta en $\text{IC}$ (generación eficiente de instrucciones) y en $\text{CPI}$ (planificación de instrucciones para evitar bloqueos de pipeline).
    \item \textbf{ISA:} Impacta en $\text{IC}$ (instrucciones potentes reducen IC) y en $\text{CPI}$ (instrucciones RISC reducen CPI).
    \item \textbf{Tecnología de Silicio / Microarquitectura:} Define $T_{\text{clock}}$ (frecuencia máxima $f_{\text{clock}}$) y la cantidad de etapas del pipeline que determinan el CPI base.
\end{itemize}
\end{examqbox}

\begin{examqbox}{7}
\textbf{¿Qué es el ''Muro de Potencia'' (Power Wall), qué ecuación física lo describe y qué cambio de paradigma provocó en 2006?}
\vspace{1.5mm}

\textbf{Respuesta:}
Es el límite físico que impidió seguir aumentando la frecuencia de reloj en procesadores mononúcleo debido a la imposibilidad de disipar el calor generado.

\textbf{Ecuación:} $P_{\text{dinámica}} = \frac{1}{2} \cdot C \cdot V_{DD}^2 \cdot f \cdot \alpha$.

Al no poder reducir $V_{DD}$ por debajo de $\sim 0.8$V (debido al incremento exponencial de corrientes de fuga sub-umbral), aumentar la frecuencia $f$ disparaba la potencia térmica por encima de los límites de enfriamiento ($>100\text{ W/cm}^2$). En 2006 forzó el cambio de paradigma hacia procesadores \textbf{Multicore} a frecuencias moderadas.
\end{examqbox}

\begin{examqbox}{8}
\textbf{Compare la filosofía RISC vs CISC en relación al conjunto de instrucciones, formato y acceso a memoria.}
\vspace{1.5mm}

\textbf{Respuesta:}
\begin{itemize}
    \item \textbf{RISC:} Conjunto reducido de instrucciones de longitud fija (16/32 bits), formato regular, arquitectura Load/Store (solo LDR/STR tocan memoria, operaciones aritméticas solo en registros), CPI cercano a 1, optimización delegada al compilador.
    \item \textbf{CISC:} Conjunto amplio de instrucciones complejas de longitud variable (1 a 15 bytes), operaciones aritméticas directas sobre memoria, CPI variable y elevado, hardware de decodificación microprogramado complejo.
\end{itemize}
\end{examqbox}

\begin{examqbox}{9}
\textbf{¿Cuál es la diferencia entre Arquitectura Mapeada en Memoria (Memory-Mapped I/O) y Mapeada en Puertos (Port-Mapped I/O)?}
\vspace{1.5mm}

\textbf{Respuesta:}
\begin{itemize}
    \item \textbf{Memory-Mapped I/O (ARM Cortex-M):} Los registros de periféricos comparten el mismo espacio de direccionamiento de 32 bits que la memoria RAM y Flash. Se accede a ellos con las mismas instrucciones estándar (\texttt{LDR} y \texttt{STR}).
    \item \textbf{Port-Mapped I/O (x86):} Los periféricos residen en un espacio de direcciones de E/S separado e independiente de la memoria principal, requiriendo instrucciones especiales de la CPU (como \texttt{IN} y \texttt{OUT}) y señales de control específicas en el bus.
\end{itemize}
\end{examqbox}

\begin{examqbox}{10}
\textbf{¿Por qué los registros de los periféricos deben declararse obligatoriamente con el calificador 'volatile' en C?}
\vspace{1.5mm}

\textbf{Respuesta:}
Porque le indica al compilador que el valor de esa dirección física puede cambiar en cualquier instante por hardware sin intervención del software. 

Si no se declara \texttt{volatile}, el optimizador del compilador asume que una variable que no es modificada explícitamente en un bucle mantiene su valor constante, guardándola en un registro interno de la CPU (caching) y suprimiendo las lecturas sucesivas a la memoria física, provocando bucles infinitos en esperas de banderas de periféricos.
\end{examqbox}

\begin{examqbox}{11}
\textbf{¿Por qué el NVIC y el SysTick están ubicados en el Private Peripheral Bus (PPB) a partir de la dirección 0xE000\_0000?}
\vspace{1.5mm}

\textbf{Respuesta:}
\begin{enumerate}
    \item \textbf{Baja Latencia y Determinismo:} El bus PPB conecta directamente el NVIC y SysTick con el núcleo de la CPU, sin competir con el tráfico de periféricos en buses AHB/APB.
    \item \textbf{Seguridad y Privilegio:} El hardware bloquea accesos no privilegiados al PPB generando fallos de protección.
    \item \textbf{Estandarización y Portabilidad CMSIS:} Al residir en direcciones idénticas en todos los microcontroladores ARM Cortex-M3 del mercado, el código de manejo de interrupciones y reloj de sistema es 100\% portable.
\end{enumerate}
\end{examqbox}

\begin{examqbox}{12}
\textbf{Explique el funcionamiento de la región Bit-Banding en Cortex-M3, sus ventajas y demuestre la fórmula de cálculo.}
\vspace{1.5mm}

\textbf{Respuesta:}
Mapea cada bit individual de una región de 1 MB (\textit{Bit-Band Region}) a una palabra de 32 bits en otra región de 32 MB (\textit{Bit-Band Alias}).

\textbf{Ventaja:} Permite modificar un único bit de un periférico o variable en RAM de forma totalmente \textbf{atómica} mediante una sola instrucción \texttt{STR}, eliminando condiciones de carrera con interrupciones sin tener que deshabilitar el NVIC.

\textbf{Fórmula:} $\text{AliasAddr} = \text{AliasBase} + (\text{ByteOffset} \times 32) + (\text{BitNumber} \times 4)$.
\end{examqbox}

\begin{examqbox}{13}
\textbf{Describa las 4 fases de la cadena de construcción (Toolchain) de GNU GCC y qué produce cada una.}
\vspace{1.5mm}

\textbf{Respuesta:}
\begin{enumerate}
    \item \textbf{Preprocesador (\texttt{cpp}):} Procesa directivas \texttt{\#include} y macros \texttt{\#define} generando código C expandido (\texttt{.i}).
    \item \textbf{Compilador (\texttt{cc1}):} Analiza la sintaxis, optimiza y genera código ensamblador (\texttt{.s}).
    \item \textbf{Ensamblador (\texttt{as}):} Traduce en dos pasadas los mnemónicos a código máquina binario en formato objeto relocable ELF (\texttt{.o}).
    \item \textbf{Enlazador (\texttt{ld}):} Combina archivos objeto con bibliotecas y el Linker Script (\texttt{.ld}), resuelve símbolos y emite el archivo ejecutable final (\texttt{.elf}).
\end{enumerate}
\end{examqbox}

\begin{examqbox}{14}
\textbf{Explique la dualidad LMA vs VMA para la sección .data en un sistema embebido y cómo se implementa en el Linker Script.}
\vspace{1.5mm}

\textbf{Respuesta:}
Las variables globales inicializadas necesitan que su valor inicial persista ante cortes de energía (deben residir en Flash - \textbf{LMA: Load Memory Address}), pero deben ser modificables durante la ejecución del programa (deben residir en RAM - \textbf{VMA: Virtual/Execution Memory Address}).

En el Linker Script se implementa con: \texttt{.data : \{ \_sdata = .; *(.data*); \_edata = .; \} > RAM AT > FLASH}, exportando el símbolo \texttt{\_sidata = LOADADDR(.data);} para el código de inicio.
\end{examqbox}

\begin{examqbox}{15}
\textbf{Detalle las 5 responsabilidades secuenciales que ejecuta el archivo de arranque (Startup / Reset\_Handler) antes de saltar a main().}
\vspace{1.5mm}

\textbf{Respuesta:}
\begin{enumerate}
    \item Instanciar la Tabla de Vectores definiendo el Stack Pointer inicial (\texttt{\_estack}) y el puntero a \texttt{Reset\_Handler}.
    \item Copiar la sección \texttt{.data} desde Flash (LMA \texttt{\_sidata}) hacia RAM (VMA \texttt{\_sdata} a \texttt{\_edata}).
    \item Limpiar a cero la sección \texttt{.bss} en RAM (entre los símbolos \texttt{\_sbss} y \texttt{\_ebss}).
    \item Llamar a la función de inicialización de relojes y memoria Flash (\texttt{SystemInit()}).
    \item Saltar a la función principal del usuario (\texttt{main()}).
\end{enumerate}
\end{examqbox}

\begin{examqbox}{16}
\textbf{¿Qué diferencia existe entre Pre-emption Priority (Prioridad de Grupo) y Sub-prioridad en el NVIC de ARM Cortex-M?}
\vspace{1.5mm}

\textbf{Respuesta:}
\begin{itemize}
    \item \textbf{Pre-emption Priority (Prioridad de Grupo):} Define si una nueva interrupción puede interrumpir y desalojar (\textbf{anidarse}) a una ISR que ya se está ejecutando (solo desaloja si su número de grupo es estrictamente menor).
    \item \textbf{Sub-prioridad:} Solo actúa como criterio de desempate cuando dos interrupciones del mismo grupo se solicitan de forma simultánea. Una menor subprioridad **NO desaloja** a otra del mismo grupo que ya esté en ejecución.
\end{itemize}
\end{examqbox}

\begin{examqbox}{17}
\textbf{¿Qué registros apila automáticamente el hardware del Cortex-M3 al entrar a una excepción y por qué se eligieron esos registros?}
\vspace{1.5mm}

\textbf{Respuesta:}
Apila automáticamente 8 registros (32 bytes) en el Stack activo: \textbf{R0, R1, R2, R3, R12, LR, PC y xPSR} en 12 ciclos de reloj.

Se eligieron porque según el estándar \textbf{AAPCS} de ARM, estos son los registros \textit{caller-saved} (que cualquier función C estándar puede sobreescribir). Al apilarlos por hardware, las ISRs pueden escribirse como funciones ordinarias en C sin necesidad de prólogos o epílogos en ensamblador.
\end{examqbox}

\begin{examqbox}{18}
\textbf{¿Qué es el valor EXC\_RETURN, dónde se carga al entrar a una interrupción y qué sucede cuando la CPU intenta saltar a él al retornar?}
\vspace{1.5mm}

\textbf{Respuesta:}
Es un valor mágico con patrón \texttt{0xFFFFFFFx} que el hardware carga en el registro \texttt{LR} al ingresar a una excepción, codificando el modo previo y la pila utilizada.

Cuando la ISR finaliza con la instrucción \texttt{bx lr}, la CPU detecta la dirección \texttt{0xFFFFFFFx}, activa automáticamente la secuencia de retorno por hardware, desapila los 8 registros restaurando el contexto previo y reanuda la ejecución en el modo original (Thread o Handler).
\end{examqbox}

\begin{examqbox}{19}
\textbf{Explique la diferencia de función entre los registros especiales PRIMASK y BASEPRI.}
\vspace{1.5mm}

\textbf{Respuesta:}
\begin{itemize}
    \item \textbf{PRIMASK (1 bit):} Al activarse (\texttt{CPSID i}) eleva la prioridad de la CPU a 0, bloqueando todas las interrupciones programables del sistema (solo permite NMI, Reset y HardFault).
    \item \textbf{BASEPRI (8 bits):} Permite un enmascaramiento selectivo por umbral: bloquea solo aquellas interrupciones con prioridad numéricamente igual o mayor a su valor (menor prioridad), permitiendo que interrupciones de tiempo real crítico sigan atendiéndose (usado en FreeRTOS para secciones críticas).
\end{itemize}
\end{examqbox}

\begin{examqbox}{20}
\textbf{Describa las 4 capas jerárquicas para activar cualquier periférico en un microcontrolador STM32.}
\vspace{1.5mm}

\textbf{Respuesta:}
\begin{enumerate}
    \item \textbf{Capa de Infraestructura (RCC):} Habilitar el reloj en el bus correspondiente (\texttt{APB1ENR} o \texttt{APB2ENR}).
    \item \textbf{Capa de Interfaz Física (GPIO/AFIO):} Configurar el modo de los pines asociados (Entrada, Salida, Función Alternativa).
    \item \textbf{Capa de Protocolo:} Configurar baud rate, prescaler, paridad, polaridad y registros de control específicos.
    \item \textbf{Capa Operativa / IRQ:} Activar el bit de encendido funcional del módulo (\texttt{UE}, \texttt{SPE}, \texttt{PE}, \texttt{ADON}, \texttt{CEN}) y habilitar la interrupción en el NVIC.
\end{enumerate}
\end{examqbox}

\begin{examqbox}{21}
\textbf{Explique el significado de los bits CPOL y CPHA en el protocolo SPI y deduzca en qué flanco se leen los datos en Modo 0 y Modo 3.}
\vspace{1.5mm}

\textbf{Respuesta:}
\begin{itemize}
    \item \textbf{CPOL (Polaridad):} Nivel de reposo de SCK ($0 = \text{Bajo/0V}$, $1 = \text{Alto/3.3V}$).
    \item \textbf{CPHA (Fase):} Flanco de muestreo ($0 = \text{Primer flanco}$, $1 = \text{Segundo flanco}$).
\end{itemize}
\textbf{Deducción:}
\begin{itemize}
    \item \textbf{Modo 0 (CPOL=0, CPHA=0):} Reposa en bajo $\rightarrow$ El primer flanco es \textbf{Ascendente (Subida)}. El dato se muestrea en flanco ascendente.
    \item \textbf{Modo 3 (CPOL=1, CPHA=1):} Reposa en alto $\rightarrow$ El primer flanco es descendente, el segundo es \textbf{Ascendente (Subida)}. El dato se muestrea en flanco ascendente.
\end{itemize}
\end{examqbox}

\begin{examqbox}{22}
\textbf{¿Por qué las líneas SDA y SCL del bus I2C operan en Drenador Abierto (Open-Drain) con resistencias Pull-Up y qué ventaja otorga en arbitraje?}
\vspace{1.5mm}

\textbf{Respuesta:}
Porque ningún nodo puede forzar un nivel alto activo (3.3V); solo pueden drenar a 0V o quedar en alta impedancia (Hi-Z), siendo el nivel alto provisto pasivamente por las resistencias Pull-Up externas.

Esto genera una configuración lógica \textbf{Wired-AND} que elimina cortocircuitos si múltiples nodos transmiten simultáneamente y permite el **Arbitraje Multimaestro sin pérdida de datos**: el nodo que envía un 1 (Hi-Z) y detecta un 0 (otro nodo drenó la línea) detecta inmediatamente que perdió el arbitraje y se retira sin corromper el mensaje del ganador.
\end{examqbox}

\begin{examqbox}{23}
\textbf{Defina las condiciones de START y STOP en el protocolo I2C y explique la regla de validez de datos.}
\vspace{1.5mm}

\textbf{Respuesta:}
\begin{itemize}
    \item \textbf{START (S):} Transición de ALTO a BAJO en SDA mientras SCL está en ALTO.
    \item \textbf{STOP (P):} Transición de BAJO a ALTO en SDA mientras SCL está en ALTO.
    \item \textbf{Regla de Validez de Datos:} Durante la transmisión de bits de datos, la línea SDA **debe permanecer estable** mientras SCL está en nivel ALTO. La línea SDA **únicamente puede conmutar cuando SCL está en nivel BAJO**.
\end{itemize}
\end{examqbox}

\begin{examqbox}{24}
\textbf{En una comunicación UART 9600 8N1, ¿cuántos caracteres útiles por segundo se transfieren y qué representa el bit de START?}
\vspace{1.5mm}

\textbf{Respuesta:}
Una trama 8N1 contiene 10 bits por carácter (1 Start + 8 Datos + 0 Paridad + 1 Stop). 

\textbf{Tasa de transferencia útil:}
$$\text{Caracteres/segundo} = \frac{9600\text{ bits/s}}{10\text{ bits/carácter}} = \mathbf{960\text{ caracteres/s}}$$

El bit de START es un nivel 0 lógico (flanco descendente) que rompe el estado de reposo en nivel alto de la línea y sincroniza los temporizadores de muestreo internos del receptor.
\end{examqbox}

\begin{examqbox}{25}
\textbf{Calcule el valor a cargar en el registro USART\_BRR para una velocidad de 115200 baudios con USART1 en APB2 a 72 MHz.}
\vspace{1.5mm}

\textbf{Respuesta:}
$$\text{USARTDIV} = \frac{f_{\text{PCLK2}}}{16 \times \text{BaudRate}} = \frac{72.000.000}{16 \times 115200} = 39,0625$$
\begin{enumerate}
    \item \textbf{Parte Entera (Mantisa):} $39 = \text{\texttt{0x027}}$ (se carga en bits [15:4]).
    \item \textbf{Parte Fraccionaria:} $0,0625 \times 16 = 1 = \text{\texttt{0x1}}$ (se carga en bits [3:0]).
    \item \textbf{Valor Final en USART1->BRR:} $\mathbf{\text{\texttt{0x0271}}}$
\end{enumerate}
\end{examqbox}

\begin{examqbox}{26}
\textbf{¿Cuál es la diferencia conceptual entre un sistema Hard Real-Time y Soft Real-Time? Dé un ejemplo de cada uno.}
\vspace{1.5mm}

\textbf{Respuesta:}
\begin{itemize}
    \item \textbf{Hard Real-Time:} El incumplimiento de un plazo temporal (\textit{deadline}) es un fallo total y catastrófico con consecuencias destructivas o riesgo de vidas (ej. despliegue de Airbag automotriz en $< 20$ ms).
    \item \textbf{Soft Real-Time:} El incumplimiento del plazo degrada la calidad del servicio pero el sistema continúa operando de forma segura (ej. caída de cuadros por segundo en la reproducción de un video o actualización de UI).
\end{itemize}
\end{examqbox}

\begin{examqbox}{27}
\textbf{Compare vTaskDelay() vs vTaskDelayUntil(). ¿Por qué vTaskDelay() produce deriva temporal (drift/jitter) en tareas periódicas?}
\vspace{1.5mm}

\textbf{Respuesta:}
\texttt{vTaskDelay()} introduce un retardo relativo a partir del instante en que es invocada, por lo que el período real es $\text{Tiempo de Ejecución de la Tarea} + \text{Delay}$, acumulando un corrimiento temporal inevitable (\textit{drift}).

\texttt{vTaskDelayUntil()} calcula el retardo en base al tiempo del ciclo anterior de forma absoluta, garantizando una frecuencia de ejecución periódica fija y determinista sin deriva temporal.
\end{examqbox}

\begin{examqbox}{28}
\textbf{¿Cuáles son las dos responsabilidades de la tarea Idle en FreeRTOS y cuál es la regla de oro de la función Idle Hook?}
\vspace{1.5mm}

\textbf{Respuesta:}
\textbf{Responsabilidades de Idle:}
\begin{enumerate}
    \item Garantizar que siempre haya al menos una tarea en estado Ready para ejecutar en la CPU.
    \item Liberar la memoria dinámica del Stack y TCB de las tareas eliminadas mediante \texttt{vTaskDelete()}.
\end{enumerate}
\textbf{Regla de Oro del Idle Hook:} Está \textbf{terminantemente prohibido} que la función \texttt{vApplicationIdleHook()} contenga operaciones bloqueantes, esperas o funciones con delay, ya que si Idle se bloquea el sistema colapsa.
\end{examqbox}

\begin{examqbox}{29}
\textbf{¿Por qué FreeRTOS implementa almacenamiento ''Por Copia de Valor'' en sus colas y qué precauciones deben tomarse al enviar punteros?}
\vspace{1.5mm}

\textbf{Respuesta:}
Implementa copia de valor (byte a byte) para desacoplar totalmente al emisor del receptor y permitir el pasaje seguro de variables locales del stack sin riesgo de corrupción al retornar la función.

\textbf{Precauciones al enviar Punteros:}
\begin{enumerate}
    \item \textbf{Transferencia de Propiedad:} El emisor no debe volver a tocar la memoria apuntada tras encolar el puntero.
    \item \textbf{Memoria Válida:} La memoria debe residir en el Heap o variables globales, nunca en stacks efímeros.
    \item \textbf{Liberación:} El receptor es el responsable exclusivo de liberar la memoria dinámica (\texttt{vPortFree()}).
\end{enumerate}
\end{examqbox}

\begin{examqbox}{30}
\textbf{Explique el patrón de ''Procesamiento Diferido de Interrupciones'' en FreeRTOS utilizando semáforos binarios y pxHigherPriorityTaskWoken.}
\vspace{1.5mm}

\textbf{Respuesta:}
Consiste en dividir la atención del evento en dos etapas:
\begin{enumerate}
    \item \textbf{La ISR de hardware (Top-Half):} Es ultracorta: atiende el hardware, limpia la bandera, desbloquea una tarea de alta prioridad con \texttt{xSemaphoreGiveFromISR(\&xHigherPriorityTaskWoken)} y solicita el cambio de contexto inmediato con \texttt{portYIELD\_FROM\_ISR(xHigherPriorityTaskWoken)}.
    \item \textbf{La Tarea Servidora (Bottom-Half):} Permanece bloqueada esperando el semáforo (\texttt{xSemaphoreTake(xSem, portMAX\_DELAY)}). Al liberarse, se ejecuta inmediatamente y realiza el procesamiento pesado a nivel de hilo (Thread Mode), permitiendo que nuevas interrupciones de hardware se sigan atendiendo sin retrasos ni degradación del determinismo.
\end{enumerate}
\end{examqbox}
"""
