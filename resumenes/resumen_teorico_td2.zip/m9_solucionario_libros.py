content = r"""
% ======================================================================
\section{Módulo 9: Solucionario Oficial de las Actividades de la Bibliografía}

En esta sección se presentan las respuestas formales, deducciones matemáticas paso a paso y justificaciones técnicas extraídas directamente de las fuentes bibliográficas oficiales y manuales de soluciones para las actividades del Módulo 8.

\subsection{Soluciones: Patterson \& Hennessy (\textit{Computer Organization and Design})}

\begin{examqbox}{Solución P\&H 1.12: Falacias de Rendimiento}
\begin{enumerate}
    \item[a)] \textbf{Falso.} La frecuencia de reloj por sí sola no determina el rendimiento. Aplicando la ecuación fundamental:
    $$\text{Tiempo CPU}_{P1} = \frac{\text{IC}_1 \times \text{CPI}_1}{f_1} = \frac{5,0 \times 10^9 \times 0,9}{4 \times 10^9\text{ Hz}} = \frac{4,5 \times 10^9}{4 \times 10^9} = \mathbf{1,125\text{ segundos}}$$
    $$\text{Tiempo CPU}_{P2} = \frac{\text{IC}_2 \times \text{CPI}_2}{f_2} = \frac{1,0 \times 10^9 \times 0,75}{3 \times 10^9\text{ Hz}} = \frac{0,75 \times 10^9}{3 \times 10^9} = \mathbf{0,250\text{ segundos}}$$
    \textbf{Conclusión:} $P_2$ es $\frac{1,125}{0,25} = \mathbf{4,5\times\text{ más rápido}}$ que $P_1$, a pesar de tener una frecuencia de reloj menor (3 GHz vs 4 GHz), debido a que ejecuta muchas menos instrucciones.
    \item[b)] Con $\text{IC}_1 = 1,0 \times 10^9$:
    $$\text{Tiempo CPU}_{P1} = \frac{1,0 \times 10^9 \times 0,9}{4 \times 10^9} = \mathbf{0,225\text{ segundos}}$$
    Ahora $P_1$ es más rápido que $P_2$ ($0,225\text{ s}$ vs $0,250\text{ s}$) por un factor de $\frac{0,250}{0,225} = \mathbf{1,11\times}$.
\end{enumerate}
\end{examqbox}

\begin{examqbox}{Solución P\&H 1.14: Mezcla de Instrucciones y CPI Ponderado}
\begin{enumerate}
    \item[a)] \textbf{Cantidad total de instrucciones (IC):}
    $$\text{IC} = (50 + 110 + 80 + 16) \times 10^6 = \mathbf{256 \times 10^6\text{ instrucciones}}$$
    \textbf{Ciclos de reloj totales:}
    $$\text{Ciclos} = (50 \times 10^6 \times 1) + (110 \times 10^6 \times 1) + (80 \times 10^6 \times 4) + (16 \times 10^6 \times 2)$$
    $$\text{Ciclos} = (50 + 110 + 320 + 32) \times 10^6 = \mathbf{512 \times 10^6\text{ ciclos}}$$
    $$\text{CPI Ponderado} = \frac{512 \times 10^6}{256 \times 10^6} = \mathbf{2,0}$$
    $$\text{Tiempo de CPU} = \frac{512 \times 10^6\text{ ciclos}}{2 \times 10^9\text{ Hz}} = \mathbf{0,256\text{ segundos (256 ms)}}$$
    \item[b)] Para duplicar la velocidad, el tiempo debe reducirse a $0,128\text{ s}$, lo que exige un total de $256 \times 10^6\text{ ciclos}$ (reducción de 256 millones de ciclos).
    Como las instrucciones FP consumen en total solo $50 \times 10^6\text{ ciclos}$, incluso si su CPI fuera 0 (tiempo cero), solo se ahorrarían 50 millones de ciclos. \textbf{Es físicamente imposible alcanzar la meta optimizando únicamente las instrucciones FP} (demostración de la Ley de Amdahl).
    \item[c)] Las instrucciones L/S consumen actualmente $320 \times 10^6\text{ ciclos}$. Para ahorrar 256 millones de ciclos, deben pasar a consumir $320 - 256 = 64 \times 10^6\text{ ciclos}$.
    $$\text{CPI}_{\text{L/S nuevo}} = \frac{64 \times 10^6\text{ ciclos}}{80 \times 10^6\text{ instrucciones}} = \mathbf{0,8}$$
    El CPI de L/S debe reducirse de 4 a 0,8 (una mejora de $\frac{4}{0,8} = \mathbf{5\times}$).
    \item[d)] Nuevos ciclos:
    $$\text{Ciclos}_{\text{nuevo}} = (50 \times 0,6) + (110 \times 0,6) + (80 \times 2,8) + (16 \times 1,4) = 30 + 66 + 224 + 22,4 = \mathbf{342,4 \times 10^6}$$
    $$\text{Tiempo}_{\text{nuevo}} = \frac{342,4 \times 10^6}{2 \times 10^9} = \mathbf{0,1712\text{ segundos}}$$
    \textbf{Mejora global:} $\frac{0,256}{0,1712} = \mathbf{1,495\times}$ (el programa corre un 49,5\% más rápido).
\end{enumerate}
\end{examqbox}

\begin{examqbox}{Solución P\&H 1.15: Ley de Amdahl con Sobrecarga}
\begin{enumerate}
    \item[a)] La fórmula del tiempo con $p$ procesadores es $T(p) = \frac{100}{p} + 4\text{ segundos}$:
    \begin{itemize}
        \item $p = 2 \rightarrow T(2) = \frac{100}{2} + 4 = \mathbf{54\text{ s}} \rightarrow S = \frac{100}{54} = \mathbf{1,85\times}$
        \item $p = 4 \rightarrow T(4) = \frac{100}{4} + 4 = \mathbf{29\text{ s}} \rightarrow S = \frac{100}{29} = \mathbf{3,45\times}$
        \item $p = 8 \rightarrow T(8) = \frac{100}{8} + 4 = \mathbf{16,5\text{ s}} \rightarrow S = \frac{100}{16,5} = \mathbf{6,06\times}$
        \item $p = 16 \rightarrow T(16) = \frac{100}{16} + 4 = \mathbf{10,25\text{ s}} \rightarrow S = \frac{100}{10,25} = \mathbf{9,76\times}$
        \item $p = 64 \rightarrow T(64) = \frac{100}{64} + 4 = 1,56 + 4 = \mathbf{5,56\text{ s}} \rightarrow S = \frac{100}{5,56} = \mathbf{17,98\times}$
    \end{itemize}
    \item[b)] Límite asintótico con infinitos procesadores:
    $$\lim_{p \rightarrow \infty} T(p) = \lim_{p \rightarrow \infty} \left(\frac{100}{p} + 4\right) = 0 + 4 = \mathbf{4\text{ segundos}}$$
    $$\text{Aceleración Máxima Teórica } S_{\text{max}} = \frac{100\text{ s}}{4\text{ s}} = \mathbf{25\times}$$
\end{enumerate}
\end{examqbox}

\begin{examqbox}{Solución P\&H 2.12: Tabla de Símbolos y Reubicación}
\begin{enumerate}
    \item[a)] 
    \begin{itemize}
        \item \textbf{Tabla de Símbolos (Symbol Table):} Lista todos los identificadores con visibilidad global (nombres de funciones exportadas, variables globales) junto con su sección y dirección relativa (offset) dentro del archivo objeto.
        \item \textbf{Tabla de Reubicación (Relocation Table):} Lista las líneas de código que contienen direcciones absolutas o saltos a símbolos que no pudieron ser resueltos durante el ensamblado porque pertenecen a otros archivos objeto.
    \end{itemize}
    \item[b)] El ensamblador genera la instrucción de salto \texttt{B} dejando un campo de offset en cero. El \textit{Linker}, tras agrupar todas las secciones \texttt{.text} y asignar las direcciones finales de memoria, calcula la distancia exacta en bytes ($\text{Destino} - \text{Origen} - 4$) y parchea el opcode binario con el desplazamiento relativo final.
\end{enumerate}
\end{examqbox}

\subsection{Soluciones: Harris \& Harris (\textit{Digital Design and Computer Architecture})}

\begin{examqbox}{Solución H\&H 6.1: Principios de Diseño en ARM}
\begin{enumerate}
    \item[a)] \textbf{Regularidad favorece simplicidad:} Todas las instrucciones de procesamiento de datos tienen 3 operandos (dos fuentes y un destino: \texttt{ADD Rd, Rn, Rm}).
    \item[b)] \textbf{Hacer el caso común rápido:} La arquitectura incluye un \textit{Barrel Shifter} por hardware que permite desplazar un operando en el mismo ciclo de reloj de una suma o resta.
    \item[c)] \textbf{Menor es más rápido:} Un banco de solo 16 registros visibles (R0-R15) permite decodificaciones ultrarrápidas y acceso en fracciones de nanosegundo.
    \item[d)] \textbf{Buen diseño exige buenos compromisos:} El conjunto de instrucciones \textbf{Thumb-2} compromete parte de la flexibilidad de 32 bits a cambio de instrucciones de 16 bits que reducen el tamaño de código en un 35\% con solo un 2\% de pérdida de rendimiento.
\end{enumerate}
\end{examqbox}

\begin{examqbox}{Solución H\&H 6.3 \& 6.4: Direccionamiento por Bytes}
\begin{enumerate}
    \item[a)] Cada palabra de 32 bits contiene 4 bytes. La dirección del primer byte de la palabra 42 es:
    $$\text{Dirección en Bytes} = 42 \times 4 = 168 = \mathbf{\text{\texttt{0x0000\_00A8}}}$$
    \item[b)] Los 4 bytes ocupan las direcciones consecutivas: \texttt{0x0000\_00A8}, \texttt{0x0000\_00A9}, \texttt{0x0000\_00AA} y \texttt{0x0000\_00AB}.
    \item[c)] La memoria física está organizada en bancos de 32 bits con líneas de dirección alineadas a múltiplos de 4 (bits [1:0] = 00). Acceder a una dirección no alineada como \texttt{0x2B} exige que el hardware realice dos accesos sucesivos a memoria y recombine los bytes mediante desplazamientos, duplicando el tiempo de acceso o disparando un \texttt{UsageFault} si la bandera \texttt{UNALIGN\_TRP} está activa.
\end{enumerate}
\end{examqbox}

\begin{examqbox}{Solución H\&H 6.5 \& 6.8: Endianness en Memoria}
\begin{enumerate}
    \item[a)] Para el valor \texttt{0x12345678} (MSB = \texttt{0x12}, LSB = \texttt{0x78}):
    \begin{center}
    \small
    \begin{tabular}{@{}lcc@{}}
    \toprule
    \textbf{Dirección} & \textbf{Little-Endian (ARM)} & \textbf{Big-Endian} \\
    \midrule
    \texttt{0x2000\_0000} (Base) & \textbf{\texttt{0x78}} (Byte menos significativo) & \textbf{\texttt{0x12}} (Byte más significativo) \\
    \texttt{0x2000\_0001} & \textbf{\texttt{0x56}} & \textbf{\texttt{0x34}} \\
    \texttt{0x2000\_0002} & \textbf{\texttt{0x34}} & \textbf{\texttt{0x56}} \\
    \texttt{0x2000\_0003} & \textbf{\texttt{0x12}} (Byte más significativo) & \textbf{\texttt{0x78}} (Byte menos significativo) \\
    \bottomrule
    \end{tabular}
    \end{center}
    \item[b)] Al hacer un cast del puntero de 32 bits a un puntero de caracteres (\texttt{char *p}), \texttt{*p} desreferencia únicamente el primer byte en la dirección base. En Little-Endian el valor 1 reside en el primer byte ($\text{*p} == 1$); en Big-Endian el primer byte contiene 0.
\end{enumerate}
\end{examqbox}

\begin{examqbox}{Solución H\&H 6.27: Estándar AAPCS y Stacking}
\begin{enumerate}
    \item[a)] \textbf{Callee-Saved (Preservados por el receptor):} \texttt{R4 -- R11}, \texttt{SP} (R13). Si una función necesita usarlos, debe guardarlos en el stack con \texttt{PUSH} y restaurarlos con \texttt{POP} antes de retornar.
    \item[b)] \textbf{Caller-Saved (Efímeros / Parámetros):} \texttt{R0 -- R3} (argumentos y retorno), \texttt{R12} (scratch register), \texttt{LR} (R14), \texttt{PC} (R15) y \texttt{xPSR}.
    \item[c)] Debido a que cualquier función escrita en C puede sobreescribir los registros \textit{Caller-Saved} sin restaurarlos, el hardware del Cortex-M3 fue diseñado para apilar automáticamente por hardware exactamente esos 8 registros (\texttt{R0-R3, R12, LR, PC, xPSR}) en 12 ciclos, permitiendo escribir ISRs directamente como funciones ordinarias en C.
\end{enumerate}
\end{examqbox}

\subsection{Soluciones: Joseph Yiu (\textit{The Definitive Guide to ARM Cortex-M3/M4})}

\begin{examqbox}{Solución Yiu 7.1: Prioridades y Desalojo en el NVIC}
\begin{enumerate}
    \item[a)] \textbf{SÍ desaloja.} La Interrupción A tiene Preemption Priority $= 1$, que es numéricamente menor (mayor prioridad de grupo) que la Interrupción B (Preemption Priority $= 2$).
    \item[b)] \textbf{NO desaloja.} La Interrupción C y la Interrupción A tienen la misma Preemption Priority ($1$). Aunque C tiene una menor Sub-priority ($0$ vs $2$), la subprioridad NO otorga derecho de desalojo sobre una ISR que ya está corriendo. C quedará en estado Pending hasta que A termine.
    \item[c)] Se atiende primero la \textbf{Interrupción C}. Al ocurrir simultáneamente en Thread Mode, tienen igual Preemption Priority ($1$), por lo que el desempate lo define la Sub-priority (C tiene subprioridad 0, más prioritaria que el 2 de A).
\end{enumerate}
\end{examqbox}

\begin{examqbox}{Solución Yiu 7.3: Ahorro de Ciclos con Tail-Chaining}
\begin{enumerate}
    \item[a)] \textbf{Sin Tail-Chaining:}
    $$\text{Ciclos} = \text{Stacking}_1 (12) + \text{ISR}_1 + \text{Unstacking}_1 (12) + \text{Stacking}_2 (12) + \text{ISR}_2 + \text{Unstacking}_2 (12)$$
    Sobrecarga total de hardware $= 12 + 12 + 12 + 12 = \mathbf{48\text{ ciclos}}$.
    \item[b)] \textbf{Con Tail-Chaining en Cortex-M3:}
    $$\text{Ciclos} = \text{Stacking}_1 (12) + \text{ISR}_1 + \text{Tail-Chain} (6) + \text{ISR}_2 + \text{Unstacking}_2 (12)$$
    Sobrecarga total de hardware $= 12 + 6 + 12 = \mathbf{30\text{ ciclos}}$.
    $$\text{Ahorro Absoluto} = 48 - 30 = \mathbf{18\text{ ciclos}} \quad \left(\mathbf{37,5\%\text{ de reducción}}\text{ en la sobrecarga de interrupción}\right).$$
\end{enumerate}
\end{examqbox}

\subsection{Soluciones: Richard Barry (\textit{Mastering the FreeRTOS Real Time Kernel})}

\begin{examqbox}{Solución FreeRTOS 3.1: Inanición de Tareas}
\begin{enumerate}
    \item[a)] El Scheduler preemptivo ejecutará continuamente la Tarea 1 por ser la de mayor prioridad (Prioridad 3). Como nunca entra en estado Blocked, **las Tareas 2 y 3 jamás recibirán tiempo de CPU**. Este fenómeno se denomina \textbf{Inanición de Tareas (\textit{Task Starvation})}.
    \item[b)] Debe reestructurarse la Tarea 1 para que, tras completar su cálculo de 5 ms, ceda voluntariamente el control de la CPU bloqueándose mediante una función de retardo:
\begin{lstlisting}
void vTarea1(void *pvParameters) {
    for(;;) {
        EjecutarCalculoPesado(); // 5 ms de trabajo
        vTaskDelay(pdMS_TO_TICKS(95)); // Se bloquea 95 ms permitiendo correr a Tareas 2 y 3
    }
}
\end{lstlisting}
\end{enumerate}
\end{examqbox}

\begin{examqbox}{Solución FreeRTOS 4.2: Dimensionamiento de Colas y Copia por Valor}
\begin{enumerate}
    \item[a)] Tamaño de la estructura: $\text{sizeof}(\text{Telemetria\_t}) = 4 + 4 + 4 = 12\text{ bytes}$.
    $$\text{Memoria para datos} = 10 \times 12\text{ bytes} = \mathbf{120\text{ bytes en el Heap}} \quad (+ \text{estructura de control de la cola } \sim 76\text{ bytes}).$$
    \item[b)] Porque \texttt{xQueueSend()} realiza una copia profunda byte a byte (\textit{memcpy}) desde la dirección de la variable local hacia el buffer interno de la cola en el Heap de FreeRTOS. Cuando la función emisora retorna y destruye su stack frame, los datos ya están resguardados en la memoria persistente del kernel.
\end{enumerate}
\end{examqbox}
"""
