content = r"""
% ======================================================================
\section{Módulo 2: Arquitectura ARMv7-M, Núcleo Cortex-M3 y Mapeo de Memoria}

\subsection{Comparación Detallada: Arquitecturas RISC vs CISC}
\begin{center}
\small
\begin{tabularx}{\textwidth}{@{}p{3.2cm}XX@{}}
\toprule
\textbf{Característica} & \textbf{RISC (ARM, MIPS, RISC-V)} & \textbf{CISC (x86, 8051, PIC clásico)} \\
\midrule
\textbf{Conjunto de Instrucciones} & Reducido, simple y ortogonal. Instrucciones de longitud fija (16 o 32 bits). & Complejo y extenso (cientos de variantes). Instrucciones de longitud variable (1 a 15 bytes). \\
\rowcolor{hdrgray} \textbf{Acceso a Memoria} & \textbf{Arquitectura Load/Store}: Únicamente las instrucciones \texttt{LDR} y \texttt{STR} tocan la RAM. Las operaciones aritméticas operan exclusivamente sobre registros. & Operaciones aritméticas pueden operar directamente sobre operandos en memoria (ej. \texttt{ADD [EAX], EBX}). \\
\textbf{Ciclos por Instrucción (CPI)} & Muy cercano a 1 (mayoría de instrucciones ejecutan en 1 ciclo de reloj). & Variable y alto (instrucciones complejas toman entre 2 y decenas de ciclos). \\
\rowcolor{hdrgray} \textbf{Pipeline (Segmentación)} & Fácil de implementar y altamente eficiente debido a la longitud y tiempos uniformes. & Complejo de segmentar por la longitud variable y micro-operaciones internas. \\
\textbf{Filosofía de Optimización} & Traslada la complejidad al \textbf{Compilador}, simplificando el silicio para ahorrar área y consumo. & Traslada la complejidad al \textbf{Hardware} (decodificadores microprogramados complejos). \\
\bottomrule
\end{tabularx}
\end{center}

\subsection{El Núcleo ARM Cortex-M3 y el Juego Thumb-2}
El Cortex-M3 implementa la arquitectura \textbf{ARMv7-M}. Opera exclusivamente con el conjunto de instrucciones \textbf{Thumb-2}, que combina instrucciones de 16 bits (alta densidad de código) e instrucciones de 32 bits (alto rendimiento) sin necesidad de conmutar modos de CPU.
\begin{itemize}
    \item \textbf{Arquitectura Harvard Modificada:} Posee buses separados para instrucciones (I-Code) y datos (D-Code) hacia la memoria interna, y un bus de Sistema (S-Bus) para periféricos y SRAM, permitiendo accesos simultáneos sin cuellos de botella de Von Neumann.
    \item \textbf{Pipeline de 3 etapas:} Fetch (Búsqueda), Decode (Decodificación) y Execute (Ejecución).
\end{itemize}

\subsection{Modelo de Registros del Programador (Core Registers)}
El Cortex-M3 posee un banco de registros de 32 bits accesibles por software:

\begin{center}
\small
\begin{tabularx}{\textwidth}{@{}llX@{}}
\toprule
\textbf{Registro} & \textbf{Nombre} & \textbf{Función y Características} \\
\midrule
\texttt{R0 -- R7} & Registros Bajos (\textit{Low Registers}) & Accesibles por todas las instrucciones Thumb de 16 y 32 bits. Parámetros y retorno en C (R0-R3). \\
\texttt{R8 -- R12} & Registros Altos (\textit{High Registers}) & Registros de propósito general de 32 bits. \\
\rowcolor{hdrgray} \texttt{R13 / SP} & Stack Pointer (Puntero de Pila) & Físicamente desdoblado en dos registros (bancados): \textbf{MSP} (Main) y \textbf{PSP} (Process). \\
\texttt{R14 / LR} & Link Register (Registro de Enlace) & Almacena la dirección de retorno de subrutinas (\texttt{BL}) o el código \texttt{EXC\_RETURN} en excepciones. \\
\rowcolor{hdrgray} \texttt{R15 / PC} & Program Counter & Apunta a la instrucción a ejecutar. \textbf{Bit 0 debe ser 1} para indicar ejecución en modo Thumb. \\
\texttt{xPSR} & Program Status Register & Registro de estado compuesto por tres vistas: APSR, IPSR y EPSR. \\
\bottomrule
\end{tabularx}
\end{center}

\begin{conceptbox}{Estructura del Registro de Estado xPSR}
El registro \texttt{xPSR} es una vista combinada de tres registros de estado:
\begin{enumerate}
    \item \textbf{APSR (Application PSR):} Bits [31:27] contienen los flags de condición aritmética:
    \begin{itemize}
        \item \textbf{N (Negative):} 1 si el resultado de la operación es negativo (bit 31 = 1).
        \item \textbf{Z (Zero):} 1 si el resultado de la operación es exactamente cero.
        \item \textbf{C (Carry):} 1 si hubo acarreo en una suma o no hubo préstamo en una resta.
        \item \textbf{V (Overflow):} 1 si hubo desbordamiento en complemento a dos con signo.
        \item \textbf{Q (Saturation):} Indica saturación en operaciones matemáticas DSP/saturantes.
    \end{itemize}
    \item \textbf{IPSR (Interrupt PSR):} Bits [8:0] contienen el número de excepción activa actual (0 = Modo Thread / no hay excepción; 15 = SysTick; 16+ = IRQ de periférico).
    \item \textbf{EPSR (Execution PSR):} Contiene el \textbf{bit T (Thumb, bit 24)}, que debe ser siempre 1. Si se intenta ejecutar una instrucción con $T=0$, el procesador entra inmediatamente en fallo de hardware (\texttt{HardFault} o \texttt{UsageFault}).
\end{enumerate}
\end{conceptbox}

\subsection{Modos de Operación y Niveles de Privilegio}
Cortex-M3 define una matriz de seguridad de $2 \times 2$ entre modos y privilegios:

\begin{center}
\small
\begin{tabularx}{\textwidth}{@{}p{3.0cm}XX@{}}
\toprule
\textbf{Nivel de Privilegio} & \textbf{Thread Mode (Modo Hilo)} & \textbf{Handler Mode (Modo Manejador)} \\
\midrule
\textbf{Privileged (Privilegiado)} & Modo de ejecución normal del sistema operativo o aplicaciones Bare-Metal simples. Acceso irrestricto a todo el mapa de memoria y registros de control. Usa MSP o PSP. & Modo en que se ejecutan \textbf{TODAS} las excepciones e interrupciones (ISRs). Siempre es privilegiado. Usa exclusivamente \textbf{MSP}. \\
\rowcolor{hdrgray} \textbf{Unprivileged / User (No Privilegiado)} & Ejecución de tareas de usuario en un RTOS. Acceso bloqueado a la región PPB (\texttt{0xE000\_0000}, NVIC, SysTick) y restringido por MPU. Usa típicamente \textbf{PSP}. & \textit{No permitido.} Las interrupciones nunca se ejecutan en modo no privilegiado. \\
\bottomrule
\end{tabularx}
\end{center}

\begin{conceptbox}{El Registro de Control (CONTROL)}
El registro especial \texttt{CONTROL} posee dos bits fundamentales configurables por software:
\begin{itemize}
    \item \textbf{Bit 0 (nPRIV):} 0 = Nivel Privilegiado; 1 = Nivel No Privilegiado (Usuario).
    \item \textbf{Bit 1 (SPSEL):} 0 = Utiliza el Main Stack Pointer (MSP); 1 = Utiliza el Process Stack Pointer (PSP) en Thread Mode.
\end{itemize}
\textit{Transición de Seguridad:} Un software no privilegiado NO puede escribir \texttt{CONTROL} para volver a ser privilegiado. La única forma de recuperar privilegios es solicitar un servicio al sistema operativo mediante la instrucción de interrupción por software \texttt{SVC} (\textit{Supervisor Call}), la cual entra a Handler Mode en modo privilegiado.
\end{conceptbox}

\subsection{Mapeo de Memoria y Decodificación de Direcciones}
El Cortex-M3 posee un bus de direcciones de 32 bits que define un espacio plano y continuo de \textbf{4 GiB} (\texttt{0x0000\_0000} a \texttt{0xFFFF\_FFFF}):

\begin{center}
\small
\begin{tabularx}{\textwidth}{@{}lllX@{}}
\toprule
\textbf{Región} & \textbf{Rango de Direcciones} & \textbf{Tamaño} & \textbf{Uso y Asignación en STM32F103} \\
\midrule
\rowcolor{hdrgray} \textbf{Code / Flash} & \texttt{0x0000\_0000 -- 0x1FFF\_FFFF} & 512 MB & Memoria Flash del programa (\texttt{0x0800\_0000}), Boot ROM (\texttt{0x1FFF\_F000}). \\
\textbf{SRAM} & \texttt{0x2000\_0000 -- 0x3FFF\_FFFF} & 512 MB & Memoria RAM estática interna (\texttt{0x2000\_0000}, 20 KB en BluePill). \\
\rowcolor{hdrgray} \textbf{Peripherals} & \texttt{0x4000\_0000 -- 0x5FFF\_FFFF} & 512 MB & Registros de periféricos en buses APB1, APB2 y AHB (GPIO, ADC, TIM, USART, etc.). \\
\textbf{External RAM} & \texttt{0x6000\_0000 -- 0x9FFF\_FFFF} & 1 GB & Memorias externas FSMC (NOR, NAND, SRAM externa). \\
\rowcolor{hdrgray} \textbf{External Device} & \texttt{0xA000\_0000 -- 0xDFFF\_FFFF} & 1 GB & Dispositivos externos mapeados. \\
\textbf{Private Periph.} & \texttt{0xE000\_0000 -- 0xE00F\_FFFF} & 1 MB & \textbf{PPB (Core)}: NVIC (\texttt{0xE000\_E100}), SysTick (\texttt{0xE000\_E010}), SCB (\texttt{0xE000\_ED00}), MPU. \\
\bottomrule
\end{tabularx}
\end{center}

\begin{conceptbox}{¿Por qué el NVIC y SysTick están en el PPB (0xE000\_0000)?}
El bus PPB (\textit{Private Peripheral Bus}) es un bus interno exclusivo de ARM que conecta el núcleo directamente con el NVIC y SysTick.
\begin{enumerate}
    \item \textbf{Latencia Mínima y Determinismo:} Las operaciones sobre el NVIC y SysTick no compiten con las transferencias de periféricos en los buses AHB/APB.
    \item \textbf{Seguridad y Privilegio:} El hardware bloquea automáticamente cualquier intento de acceso al PPB desde software no privilegiado, generando un fallo de bus.
    \item \textbf{Portabilidad Absoluta (CMSIS):} Al estar ubicados en las mismas direcciones en cualquier chip ARM Cortex-M3 (ST, NXP, TI, Microchip), el código de control de interrupciones es 100\% portable.
\end{enumerate}
\end{conceptbox}

\subsection{El Calificador 'volatile' en C para Acceso a Registros}
En C, el calificador \texttt{volatile} le indica al compilador que el valor de una variable o posición de memoria puede ser modificado por eventos externos al flujo del programa (hardware, interrupciones o DMA).

\begin{warnbox}{¿Qué ocurre si NO se usa 'volatile'?}
El optimizador del compilador (GCC con \texttt{-O2} o \texttt{-O3}) asume que si el código no modifica una variable en un bucle, su valor nunca cambia. Por lo tanto, almacena el valor en un registro de la CPU (\textit{caching en R0-R12}) y nunca vuelve a leer la memoria física.

\textbf{Ejemplo de fallo fatal sin volatile:}
\begin{lstlisting}
// Espera a que el ADC termine la conversion (flag EOC en bit 1)
#define ADC_SR (*(uint32_t *)0x40012400) // ERROR: Falta volatile
while (!(ADC_SR & (1 << 1))); // El compilador lee ADC_SR UNA SOLA VEZ y entra en bucle infinito.

// Declaracion correcta:
#define ADC_SR (*(volatile uint32_t *)0x40012400) // Correcto: lee la direccion fisica en cada vuelta
\end{lstlisting}
\end{warnbox}

\subsection{Mecanismo de Bit-Banding (Operaciones Atómicas de 1 Bit)}
Cortex-M3 introduce la técnica de \textbf{Bit-Banding}, que mapea cada bit individual de una región de 1 MB (\textit{Bit-Band Region}) a una palabra completa de 32 bits en otra región de 32 MB (\textit{Bit-Band Alias}).
\begin{itemize}
    \item \textbf{Ventaja Crítica:} Permite modificar un único bit en un periférico o variable en RAM mediante una sola instrucción de escritura (\texttt{STR}), garantizando \textbf{atomicidad por hardware} (libre de condiciones de carrera con interrupciones) sin necesidad de instrucciones de deshabilitación global de interrupciones.
    \item \textbf{Regiones Soportadas:}
    \begin{enumerate}
        \item \textbf{SRAM Bit-Band:} Región base \texttt{0x2000\_0000} (1 MB) $\rightarrow$ Alias en \texttt{0x2200\_0000} (32 MB).
        \item \textbf{Peripheral Bit-Band:} Región base \texttt{0x4000\_0000} (1 MB) $\rightarrow$ Alias en \texttt{0x4200\_0000} (32 MB).
    \end{enumerate}
\end{itemize}

\begin{formulabox}{Fórmula de Cálculo de Dirección de Bit-Band Alias}
$$\text{Alias\_Address} = \text{Alias\_Base} + (\text{Byte\_Offset} \times 32) + (\text{Bit\_Number} \times 4)$$
\textbf{Ejemplo:} Modificar el bit 4 del puerto GPIOA ODR (\texttt{0x4001\_080C}):
\begin{itemize}
    \item $\text{Alias\_Base} = \text{\texttt{0x4200\_0000}}$
    \item $\text{Byte\_Offset} = \text{\texttt{0x4001\_080C}} - \text{\texttt{0x4000\_0000}} = \text{\texttt{0x1080C}} = 67.596$
    \item $\text{Bit\_Number} = 4$
    \item $\text{Alias\_Address} = \text{\texttt{0x4200\_0000}} + (67.596 \times 32) + (4 \times 4) = \text{\texttt{0x4200\_0000}} + \text{\texttt{0x210180}} + \text{\texttt{0x10}} = \mathbf{\text{\texttt{0x4221\_0190}}}$
    \item Escribir un 1 en \texttt{*(volatile uint32\_t *)0x42210190 = 1;} pone en 1 el bit 4 de forma puramente atómica.
\end{itemize}
\end{formulabox}
"""
