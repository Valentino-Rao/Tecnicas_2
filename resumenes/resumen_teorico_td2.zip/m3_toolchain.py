content = r"""
% ======================================================================
\section{Módulo 3: Cadena de Construcción (Toolchain), Enlazado y Arranque}

\subsection{Las Cuatro Fases del Toolchain de Compilación}
La transformación de código fuente en C (\texttt{.c}) a un archivo binario ejecutable en el microcontrolador involucra cuatro etapas secuenciales coordinadas por la suite GNU GCC (\texttt{arm-none-eabi}):

\begin{center}
\small
\begin{tabularx}{\textwidth}{@{}lllX@{}}
\toprule
\textbf{Fase} & \textbf{Herramienta} & \textbf{Entrada $\rightarrow$ Salida} & \textbf{Responsabilidad y Operación Interna} \\
\midrule
\textbf{1. Preprocesamiento} & Preprocesador (\texttt{cpp}) & \texttt{.c}, \texttt{.h} $\rightarrow$ \texttt{.i} & Expande directivas \texttt{\#include}, reemplaza macros \texttt{\#define} y resuelve bloques condicionales (\texttt{\#ifdef}, \texttt{\#ifndef}). \\
\rowcolor{hdrgray} \textbf{2. Compilación} & Compilador (\texttt{cc1}) & \texttt{.i} $\rightarrow$ \texttt{.s} & Análisis léxico, sintáctico y semántico. Genera árbol AST, optimiza código (\texttt{-O2}, \texttt{-Os}) y emite código ensamblador específico de ARMv7-M. \\
\textbf{3. Ensamblado} & Ensamblador (\texttt{as}) & \texttt{.s} $\rightarrow$ \texttt{.o} & Traduce mnemónicos a código máquina binario. Opera en \textbf{dos pasadas} generando un archivo objeto en formato \textbf{ELF} (\textit{Executable and Linkable Format}). \\
\rowcolor{hdrgray} \textbf{4. Enlazado} & Enlazador (\texttt{ld}) & \texttt{.o}, \texttt{.a}, \texttt{.ld} $\rightarrow$ \texttt{.elf} & Concatena secciones homogéneas, resuelve referencias cruzadas externas y asigna direcciones de memoria física definitivas. \\
\bottomrule
\end{tabularx}
\end{center}

\begin{conceptbox}{¿Por qué el Ensamblador requiere Dos Pasadas?}
\begin{enumerate}
    \item \textbf{Primera Pasada (Construcción de la Tabla de Símbolos):} Lee el archivo línea por línea y mantiene un Contador de Posición (\textit{Location Counter}). Registra todas las etiquetas (nombres de funciones, variables) y les asocia un offset relativo. No puede resolver saltos hacia adelante (\textit{forward references}).
    \item \textbf{Segunda Pasada (Emisión de Código Máquina):} Traduce cada instrucción mnemónica a su opcode binario exacto, reemplazando todas las etiquetas por los offsets calculados en la primera pasada y emitiendo el archivo objeto relocable \texttt{.o}.
\end{enumerate}
\end{conceptbox}

\subsection{Estructura de Secciones de un Archivo Objeto y Ejecutable (ELF)}
La memoria del programa compilado se organiza en secciones estandarizadas:

\begin{center}
\small
\begin{tabularx}{\textwidth}{@{}p{2.4cm}Xp{4.5cm}p{2.8cm}@{}}
\toprule
\textbf{Sección} & \textbf{Contenido} & \textbf{Ubicación Física} & \textbf{Propiedades} \\
\midrule
\texttt{.isr\_vector} & Tabla de vectores de interrupción (punteros a handlers) & Inicio de Flash (\texttt{0x0800\_0000}) & Solo lectura (\texttt{r-x}) \\
\rowcolor{hdrgray} \texttt{.text} & Código ejecutable de las funciones en lenguaje máquina & Memoria Flash & Solo lectura y ejecución (\texttt{r-x}) \\
\texttt{.rodata} & Constantes (\texttt{const}), cadenas de texto literales (\texttt{"Hola"}) & Memoria Flash & Solo lectura (\texttt{r--}) \\
\rowcolor{hdrgray} \texttt{.data} & Variables globales y estáticas con valor inicial distinto de cero & LMA: Flash / VMA: RAM & Lectura y escritura (\texttt{rw-}) \\
\texttt{.bss} & Variables globales y estáticas no inicializadas o inicializadas a 0 & Memoria RAM (\texttt{0x2000\_0000}) & Lectura y escritura (\texttt{rw-}) \\
\rowcolor{hdrgray} \texttt{Stack} & Variables locales, argumentos de funciones, registros apilados & Cima de la RAM (crece hacia abajo) & Lectura y escritura (\texttt{rw-}) \\
\texttt{Heap} & Memoria dinámica asignada por el usuario (\texttt{malloc}, FreeRTOS) & Base de RAM libre (crece hacia arriba) & Lectura y escritura (\texttt{rw-}) \\
\bottomrule
\end{tabularx}
\end{center}

\subsection{Dualidad LMA vs VMA para la Sección .data}
Un microcontrolador almacena el programa en memoria no volátil (Flash) pero ejecuta operando sobre variables en memoria volátil (RAM). Esto genera una dualidad fundamental de direcciones:

\begin{conceptbox}{Definición de LMA vs VMA}
\begin{itemize}
    \item \textbf{LMA (Load Memory Address):} Dirección física donde reside la sección al momento de grabar (\textit{flashear}) el chip. Es una dirección no volátil dentro de la memoria Flash.
    \item \textbf{VMA (Virtual / Execution Memory Address):} Dirección física donde la CPU accede y modifica los datos durante la ejecución normal del programa. Es una dirección dentro de la memoria RAM.
\end{itemize}
\textbf{Para la sección \texttt{.data}:} Sus valores iniciales (ej. \texttt{int sensor\_offset = 120;}) deben guardarse en Flash (LMA) para no perderse ante cortes de energía, pero el procesador debe poder modificar su valor en RAM (VMA).

\textbf{Sintaxis en el Linker Script (.ld):}
\begin{lstlisting}
.data :
{
    _sdata = .;        /* Marca de inicio de .data en RAM (VMA) */
    *(.data*)
    _edata = .;        /* Marca de fin de .data en RAM (VMA) */
} > RAM AT > FLASH     /* VMA en RAM, LMA en FLASH */
_sidata = LOADADDR(.data); /* Obtiene la direccion LMA de inicio en Flash */
\end{lstlisting}
\end{conceptbox}

\subsection{El Linker Script (.ld) en Detalle}
El Linker Script le indica al enlazador la topología exacta de la memoria física del microcontrolador mediante dos bloques principales:
\begin{enumerate}
    \item \textbf{Bloque \texttt{MEMORY}:} Define los nombres, atributos de acceso, direcciones base y tamaños de las memorias físicas:
\begin{lstlisting}
MEMORY
{
    FLASH (rx)  : ORIGIN = 0x08000000, LENGTH = 64K
    RAM   (rwx) : ORIGIN = 0x20000000, LENGTH = 20K
}
\end{lstlisting}
    \item \textbf{Bloque \texttt{SECTIONS}:} Define cómo se distribuyen las secciones de los archivos objeto (\texttt{.text}, \texttt{.rodata}, \texttt{.data}, \texttt{.bss}) dentro de los bloques \texttt{FLASH} y \texttt{RAM}.
\end{enumerate}

\subsection{El Código de Arranque (Startup / Reset\_Handler)}
Al energizar el microcontrolador o presionar el botón de Reset, el hardware lee de la dirección \texttt{0x0800\_0000} el valor del Stack Pointer inicial y salta a la dirección apuntada por el segundo vector: la función \texttt{Reset\_Handler}.

\begin{conceptbox}{Las 5 Responsabilidades Secuenciales del Startup (Reset\_Handler)}
Antes de transferir el control a la función \texttt{main()}, el código de arranque ejecuta estrictamente:
\begin{enumerate}
    \item \textbf{Instanciar la Tabla de Vectores de Excepción:} Coloca en la dirección base de Flash (\texttt{0x0800\_0000}) el valor del puntero \texttt{\_estack} (cima de la RAM) y los punteros a todas las ISRs.
    \item \textbf{Copiar la sección \texttt{.data} de Flash a RAM:} Lee byte a byte desde la dirección LMA (\texttt{\_sidata} en Flash) y los escribe en el rango VMA en RAM (\texttt{\_sdata} a \texttt{\_edata}).
    \item \textbf{Limpiar a Cero la sección \texttt{.bss} en RAM (Zero-Fill):} Escribe ceros (\texttt{0x00}) en todo el rango de memoria RAM delimitado entre los símbolos \texttt{\_sbss} y \texttt{\_ebss}.
    \item \textbf{Llamar a la función de Inicialización de Hardware (\texttt{SystemInit()}):} Configura los osciladores HSE, activa el multiplicador PLL a 72 MHz, ajusta los prescalers de buses y configura los 2 wait states de la memoria Flash.
    \item \textbf{Saltar a la función principal (\texttt{main()}):} Realiza el salto definitivo (\texttt{bl main}). Si \texttt{main()} alguna vez retorna, entra en un bucle infinito de seguridad (\texttt{while(1);}).
\end{enumerate}
\end{conceptbox}
"""
