content = r"""
% ======================================================================
\section{Módulo 5: Capas de Activación y Protocolos de Comunicación Serie}

\subsection{Las 4 Capas Jerárquicas de Activación de Periféricos en STM32}
En microcontroladores modernos basados en ARM, los periféricos se encuentran completamente desenergizados e incomunicados al encender el chip. Su activación requiere una secuencia jerárquica de 4 capas:

\begin{center}
\small
\begin{tabularx}{\textwidth}{@{}p{3.2cm}Xp{6.2cm}@{}}
\toprule
\textbf{Capa} & \textbf{Nombre y Función} & \textbf{Registros Involucrados} \\
\midrule
\textbf{Capa 1: Infraestructura} & Habilita la señal de reloj del bus correspondiente. & \texttt{RCC->APB2ENR} (Rápidos: GPIO, ADC1, USART1, SPI1) \\
 & & \texttt{RCC->APB1ENR} (Lentos: TIM2-4, USART2-3, SPI2, I2C1-2) \\
\rowcolor{hdrgray} \textbf{Capa 2: Interfaz Física} & Configura los pines físicos (Entrada, Salida, AF, Analógico). & \texttt{GPIOx->CRL}, \texttt{GPIOx->CRH}, \texttt{AFIO->EXTICR} \\
\textbf{Capa 3: Protocolo} & Ajusta parámetros de comunicación (baud rate, paridad, polaridad). & \texttt{USART->BRR}, \texttt{SPI->CR1}, \texttt{I2C->CCR}, \texttt{TIM->PSC/ARR} \\
\rowcolor{hdrgray} \textbf{Capa 4: Operativa / IRQ} & Enciende el módulo periférico y habilita interrupciones en el NVIC. & Bits \texttt{UE}, \texttt{SPE}, \texttt{PE}, \texttt{ADON}, \texttt{CEN} y función \texttt{NVIC\_EnableIRQ()} \\
\bottomrule
\end{tabularx}
\end{center}

\subsection{Sistema de Relojes (RCC) y el Clock Tree del STM32F103}
El árbol de reloj del microcontrolador permite derivar frecuencias de trabajo estables para la CPU y los periféricos:
\begin{itemize}
    \item \textbf{Fuentes Primarias de Oscilador:}
    \begin{itemize}
        \item \textbf{HSI (High Speed Internal):} Oscilador interno RC de 8 MHz (arranque rápido, menor precisión térmica).
        \item \textbf{HSE (High Speed External):} Cristal de cuarzo externo de 8 MHz (alta precisión y estabilidad).
        \item \textbf{LSI (Low Speed Internal):} 40 kHz para el Watchdog independiente (IWDG) y RTC de bajo costo.
        \item \textbf{LSE (Low Speed External):} Cristal de 32.768 kHz para el Real-Time Clock (RTC).
    \end{itemize}
    \item \textbf{Multiplicador PLL (Phase-Locked Loop):} Multiplica la frecuencia de HSE (8 MHz) por $\times 9$ para generar la frecuencia máxima del sistema: $\mathbf{\text{SYSCLK} = 72\text{ MHz}}$.
    \item \textbf{Jerarquía de Buses y Prescalers:}
    \begin{itemize}
        \item \textbf{AHB (Advanced High-performance Bus):} $\text{SYSCLK} / 1 = 72\text{ MHz}$. Alimenta la CPU, DMA y memoria.
        \item \textbf{APB2 (Advanced Peripheral Bus 2 - Rápido):} $\text{HCLK} / 1 = 72\text{ MHz}$.
        \item \textbf{APB1 (Advanced Peripheral Bus 1 - Lento):} $\text{HCLK} / 2 = 36\text{ MHz}$ (límite máximo de APB1).
        \item \textbf{Reloj de Temporizadores en APB1:} Si el prescaler de APB1 es mayor a 1, la arquitectura duplica internamente la frecuencia para los timers ($\times 2$), por lo que \textbf{TIM2, TIM3 y TIM4 operan a 72 MHz}.
    \end{itemize}
    \item \textbf{Latencia de Memoria Flash (Wait States):} La memoria Flash física tiene un tiempo de acceso de $\sim 40$ ns. Para frecuencias $\text{SYSCLK} > 48$ MHz se deben configurar obligatoriamente **2 ciclos de espera (\texttt{LATENCY\_2})** y el buffer de prebúsqueda (\texttt{PRFTBE}) en el registro \texttt{FLASH->ACR}.
\end{itemize}

\subsection{Capa GPIO: Decodificación de CNF y MODE}
Cada pin se configura mediante 4 bits (\texttt{CNF[1:0]} y \texttt{MODE[1:0]}) en los registros \texttt{CRL} (pines 0 a 7) y \texttt{CRH} (pines 8 a 15):

\begin{center}
\small
\begin{tabularx}{\textwidth}{@{}ccclX@{}}
\toprule
\textbf{CNF[1:0]} & \textbf{MODE[1:0]} & \textbf{Hex} & \textbf{Modo de Operación} & \textbf{Aplicación Típica} \\
\midrule
\rowcolor{hdrgray} 00 & 00 & \texttt{0x0} & Entrada Analógica & Pines conectados al ADC (ej. PA4 potenciómetro) \\
01 & 00 & \texttt{0x4} & Entrada Flotante (Reset default) & Pines RX de UART o entradas con circuito externo \\
\rowcolor{hdrgray} 10 & 00 & \texttt{0x8} & Entrada con Pull-Up / Pull-Down & Botones y pulsadores (ODR=1 Pull-Up, ODR=0 Pull-Down) \\
00 & 01 & \texttt{0x1} & Salida Push-Pull (10 MHz máx) & Control de LEDs y relés (baja velocidad, bajo ruido) \\
\rowcolor{hdrgray} 00 & 10 & \texttt{0x2} & Salida Push-Pull (2 MHz máx) & LED integrado PC13 \\
00 & 11 & \texttt{0x3} & Salida Push-Pull (50 MHz máx) & Salidas digitales de alta velocidad \\
\rowcolor{hdrgray} 01 & 11 & \texttt{0x7} & Salida Open-Drain (50 MHz máx) & Buses compartidos con pull-up (I2C) \\
10 & 11 & \texttt{0xB} & Salida Función Alternativa Push-Pull (50 MHz) & Transmisor USART1 TX (PA9), TIM2 PWM (PA2), SPI1 MOSI \\
\rowcolor{hdrgray} 11 & 11 & \texttt{0xF} & Salida Función Alternativa Open-Drain (50 MHz) & Líneas I2C1 (SCL en PB6, SDA en PB7) \\
\bottomrule
\end{tabularx}
\end{center}

\subsection{Protocolo SPI (Serial Peripheral Interface)}
\textbf{SPI} es un estándar de bus serie síncrono, maestro-esclavo y full-duplex de alta velocidad desarrollado por Motorola.

\begin{center}
\small
\begin{tabularx}{\textwidth}{@{}p{3.2cm}Xp{6.2cm}@{}}
\toprule
\textbf{Línea} & \textbf{Nombre Completo} & \textbf{Función y Dirección de la Señal} \\
\midrule
\texttt{MOSI} & Master Out Slave In & Datos transmitidos del Maestro hacia el Esclavo. \\
\rowcolor{hdrgray} \texttt{MISO} & Master In Slave Out & Datos transmitidos del Esclavo hacia el Maestro. \\
\texttt{SCK / SCLK} & Serial Clock & Señal de reloj generada exclusivamente por el Maestro para sincronizar los bits. \\
\rowcolor{hdrgray} \texttt{NSS / CS} & Chip Select (Slave Select) & Selecciona al esclavo activo. Típicamente \textbf{activo en nivel bajo (0V)}. \\
\bottomrule
\end{tabularx}
\end{center}

\begin{conceptbox}{Los 4 Modos de Reloj en SPI (CPOL y CPHA)}
El protocolo SPI se parametriza mediante dos bits en el registro de control (\texttt{SPI\_CR1}):
\begin{itemize}
    \item \textbf{CPOL (Clock Polarity):} Define el estado de la línea SCK en reposo (\textit{Idle}):
    \begin{itemize}
        \item $\text{CPOL} = 0 \rightarrow$ SCK reposa en nivel **BAJO (0V)**.
        \item $\text{CPOL} = 1 \rightarrow$ SCK reposa en nivel **ALTO (3.3V)**.
    \end{itemize}
    \item \textbf{CPHA (Clock Phase):} Define en qué flanco se realiza el muestreo del dato:
    \begin{itemize}
        \item $\text{CPHA} = 0 \rightarrow$ El dato se \textbf{muestrea en el 1er flanco} de reloj y cambia en el 2do flanco.
        \item $\text{CPHA} = 1 \rightarrow$ El dato \textbf{cambia en el 1er flanco} y se \textbf{muestrea en el 2do flanco}.
    \end{itemize}
\end{itemize}

\begin{center}
\begin{tabularx}{\textwidth}{@{}ccclX@{}}
\toprule
\textbf{Modo SPI} & \textbf{CPOL} & \textbf{CPHA} & \textbf{Nivel de Reposo} & \textbf{Flanco de Muestreo (Captura de Dato)} \\
\midrule
\textbf{Modo 0} & 0 & 0 & Bajo (0V) & \textbf{Primer Flanco (Ascendente / Flanco de Subida)} \\
\textbf{Modo 1} & 0 & 1 & Bajo (0V) & \textbf{Segundo Flanco (Descendente / Flanco de Bajada)} \\
\textbf{Modo 2} & 1 & 0 & Alto (3.3V) & \textbf{Primer Flanco (Descendente / Flanco de Bajada)} \\
\textbf{Modo 3} & 1 & 1 & Alto (3.3V) & \textbf{Segundo Flanco (Ascendente / Flanco de Subida)} \\
\bottomrule
\end{tabularx}
\end{center}
\end{conceptbox}

\begin{conceptbox}{Topologías de Red SPI: Estrella vs Daisy-Chain}
\begin{enumerate}
    \item \textbf{Topología Estrella (Esclavos Independientes):} Las líneas MOSI, MISO y SCK se comparten en paralelo. El Maestro posee una línea dedicada $\text{CS}_i$ para cada esclavo. Para hablar con el esclavo $k$, el maestro baja $\text{CS}_k = 0$ y mantiene los demás en 1.
    \begin{itemize}
        \item \textit{Ventajas:} Protocolo simple, acceso aleatorio rápido a cualquier esclavo.
        \item \textit{Desventajas:} Consume un pin GPIO del maestro por cada esclavo añadido.
    \end{itemize}
    \item \textbf{Topología Daisy-Chain (Cadena en Cascada):} Se utiliza una sola línea $\text{CS}$ común. El pin MOSI del maestro entra al MOSI del Esclavo 1; el MISO del Esclavo 1 entra al MOSI del Esclavo 2; y el MISO del último esclavo vuelve al MISO del maestro.
    \begin{itemize}
        \item \textit{Ventajas:} Requiere únicamente 4 pines en el microcontrolador sin importar la cantidad de esclavos.
        \item \textit{Desventajas:} Para actualizar un dispositivo hay que desplazar los datos a través de toda la cadena (comunicación serial secuencial rígida).
    \end{itemize}
\end{enumerate}
\end{conceptbox}

\subsection{Protocolo I2C (Inter-Integrated Circuit)}
\textbf{I2C} es un estándar de bus serie síncrono, half-duplex y multimaestro desarrollado por Philips (NXP) que utiliza únicamente **2 líneas**:

\begin{center}
\small
\begin{tabularx}{\textwidth}{@{}p{3.2cm}Xp{6.2cm}@{}}
\toprule
\textbf{Línea} & \textbf{Nombre} & \textbf{Descripción y Conexión Eléctrica} \\
\midrule
\texttt{SDA} & Serial Data & Línea bidireccional de datos en Drenador Abierto (\textit{Open-Drain}). \\
\rowcolor{hdrgray} \texttt{SCL} & Serial Clock & Línea de sincronización de reloj en Drenador Abierto con resistencia Pull-Up. \\
\bottomrule
\end{tabularx}
\end{center}

\begin{conceptbox}{El Bus Open-Drain con Pull-Up y la Lógica Wired-AND}
Ningún nodo del bus I2C puede forzar activamente un nivel alto (3.3V). Los transistores internos solo pueden drenar la línea a masa (0V) o quedar en alta impedancia (Hi-Z). El nivel alto lo imponen pasivamente resistencias de Pull-Up externas ($2,2\text{ k}\Omega$ a $4,7\text{ k}\Omega$).
\begin{itemize}
    \item \textbf{Lógica Wired-AND:} Si cualquier nodo pone la línea en 0V, el bus entero pasa a 0V. Solo si TODOS los nodos están en Hi-Z, la línea sube a 3.3V.
    \item \textbf{Ventajas:} Inmune a cortocircuitos si dos transmisores emiten simultáneamente, y permite el mecanismo de \textbf{Arbitraje Multimaestro} y \textbf{Clock Stretching}.
\end{itemize}
\end{conceptbox}

\begin{conceptbox}{Condiciones de Bus, Regla de Validez y Trama I2C}
\begin{enumerate}
    \item \textbf{Estado de Reposo (Idle):} Tanto \texttt{SDA} como \texttt{SCL} están en nivel ALTO (3.3V).
    \item \textbf{Condición de START (S):} Transición de \textbf{ALTO a BAJO en SDA} mientras \textbf{SCL está en ALTO}. Inicia la comunicación.
    \item \textbf{Condición de STOP (P):} Transición de \textbf{BAJO a ALTO en SDA} mientras \textbf{SCL está en ALTO}. Libera el bus.
    \item \textbf{Regla de Validez del Dato:} Durante la transmisión de bits normales, \textbf{SDA debe permanecer ESTABLE} durante todo el semiperíodo de SCL en ALTO. La línea SDA \textbf{SOLO puede cambiar de estado cuando SCL está en BAJO}.
    \item \textbf{Bit de ACK / NACK (Acknowledge):} Tras cada byte de 8 bits, en el 9no ciclo de reloj de SCL el receptor debe responder:
    \begin{itemize}
        \item \textbf{ACK (0 lógico):} El receptor drena SDA a 0V indicando recepción correcta.
        \item \textbf{NACK (1 lógico):} SDA queda en alto (el esclavo no existe, está ocupado o el maestro terminó de leer).
    \end{itemize}
    \item \textbf{Formato de Trama (Direccionamiento de 7 bits):}
    $$\text{START} \rightarrow [\text{Dirección Esclavo (7 bits)} + \text{Bit } R/\bar{W} (1\text{ bit})] \rightarrow \text{ACK} \rightarrow [\text{Dato (8 bits)}] \rightarrow \text{ACK} \rightarrow \text{STOP}$$
    \begin{itemize}
        \item $R/\bar{W} = 0$: El Maestro escribe datos en el Esclavo (\textit{Master Write}).
        \item $R/\bar{W} = 1$: El Maestro lee datos desde el Esclavo (\textit{Master Read}).
    \end{itemize}
\end{enumerate}
\end{conceptbox}

\begin{conceptbox}{Características Avanzadas de I2C}
\begin{itemize}
    \item \textbf{Clock Stretching (Estiramiento de Reloj):} Si un esclavo lento necesita tiempo para procesar un byte recibido o preparar el siguiente, fuerza manualmente la línea \texttt{SCL} a nivel BAJO. El maestro detecta que SCL no sube y detiene su reloj hasta que el esclavo lo libera.
    \item \textbf{Arbitraje Multimaestro:} Cuando dos maestros inician una transmisión simultáneamente, comparan el bit que intentan enviar con el estado real de la línea SDA. Debido al Wired-AND, si un maestro intenta enviar un 1 pero detecta un 0 (porque otro maestro envió 0), **pierde el arbitraje de inmediato**, desconecta su transmisor y pasa a modo esclavo sin corromper la trama del ganador.
    \item \textbf{Modos de Velocidad:} Standard (100 kbps), Fast (400 kbps), Fast Plus (1 Mbps), High-Speed (3.4 Mbps).
\end{itemize}
\end{conceptbox}

\subsection{Protocolo UART / USART y Estándar RS-232}
\textbf{UART} (\textit{Universal Asynchronous Receiver-Transmitter}) es un protocolo de comunicación serie asíncrono, full-duplex y punto a punto.

\begin{center}
\small
\begin{tabularx}{\textwidth}{@{}p{3.2cm}Xp{6.2cm}@{}}
\toprule
\textbf{Línea} & \textbf{Nombre} & \textbf{Función y Niveles de Voltaje} \\
\midrule
\texttt{TX} & Transmit Data & Línea de salida de datos del transmisor. \\
\rowcolor{hdrgray} \texttt{RX} & Receive Data & Línea de entrada de datos del receptor. \\
\texttt{RTS / CTS} & Hardware Flow Control & Request To Send (avisa que está listo) / Clear To Send (permiso para emitir). \\
\bottomrule
\end{tabularx}
\end{center}

\begin{conceptbox}{Niveles TTL/CMOS vs Estándar RS-232}
\begin{itemize}
    \item \textbf{Nivel Lógico UART (Microcontrolador):} Opera entre $0\text{V}$ (0 lógico) y $3.3\text{V}$ o $5\text{V}$ (1 lógico). Apto únicamente para distancias de pocos centímetros sobre circuito impreso.
    \item \textbf{Nivel Eléctrico RS-232 (Industrial / PC):} Protocolo bipolar con lógica invertida para mayor inmunidad al ruido y alcance hasta 15-30 metros:
    \begin{itemize}
        \item \textbf{1 lógico (Mark / Reposo):} Voltaje negativo entre $-3\text{V}$ y $-15\text{V}$ (típicamente $-9\text{V}$).
        \item \textbf{0 lógico (Space / Start):} Voltaje positivo entre $+3\text{V}$ y $+15\text{V}$ (típicamente $+9\text{V}$).
    \end{itemize}
    \item \textbf{Circuito de Adaptación:} Requiere un integrado conversor con bomba de carga como el \textbf{MAX232} o \textbf{MAX3232} que eleva e invierte los niveles de $3.3\text{V}$ a $\pm 9\text{V}$.
\end{itemize}
\end{conceptbox}

\begin{conceptbox}{Estructura de la Trama Asíncrona (8N1)}
Al no existir línea de reloj compartida, emisor y receptor deben acordar previamente una velocidad idéntica (\textbf{Baud Rate}).

\textbf{Composición de un Carácter 8N1 (10 bits totales):}
\begin{enumerate}
    \item \textbf{Estado de Reposo (Mark):} Línea en nivel ALTO constante ($1$ lógico / $-9\text{V}$).
    \item \textbf{Bit de START (1 bit):} Transición de ALTO a BAJO ($0$ lógico / $+9\text{V}$). Rompe el reposo y sincroniza los osciladores internos del receptor.
    \item \textbf{Bits de Datos (8 bits):} Se transmiten siempre con el **bit menos significativo (LSB) primero** (bits D0 a D7).
    \item \textbf{Bit de Paridad (Opcional, 0 bits en 8N1):} None, Even (Par: agrega un bit para que la suma de unos sea par) o Odd (Impar).
    \item \textbf{Bits de STOP (1 o 2 bits):} Nivel ALTO ($1$ lógico) para delimitar el fin del carácter y permitir el próximo flanco de bajada.
\end{enumerate}
\textit{Eficiencia:} En 9600 baudios 8N1, la tasa útil es $\frac{9600\text{ bps}}{10\text{ bits/char}} = \mathbf{960\text{ caracteres por segundo}}$.
\end{conceptbox}

\begin{conceptbox}{Sobremuestreo por 16 y Cálculo de BRR (Baud Rate Register)}
El receptor de hardware del STM32 ejecuta un reloj interno a $16 \times \text{BaudRate}$:
\begin{enumerate}
    \item Al detectar el flanco de bajada del Start bit, cuenta 8 pulsos de reloj para posicionarse exactamente en el **centro geométrico del bit**.
    \item Toma las muestras **8, 9 y 10** de cada bit y aplica un circuito de **votación por mayoría de 2 sobre 3** para rechazar ruidos transitorios.
\end{enumerate}

\begin{formulabox}{Cálculo del Divisor de Baudios (USART\_BRR)}
$$\text{USARTDIV} = \frac{f_{\text{PCLK}}}{16 \times \text{BaudRate}}$$
\begin{itemize}
    \item \textbf{Mantisa (bits [15:4]):} Parte entera de $\text{USARTDIV}$.
    \item \textbf{Fracción (bits [3:0]):} $\text{round}(\text{Parte Decimal} \times 16)$.
\end{itemize}

\textbf{Ejemplo 1: 9600 bps con USART1 en APB2 (72 MHz):}
$$\text{USARTDIV} = \frac{72.000.000}{16 \times 9600} = 468,75$$
\begin{itemize}
    \item Mantisa $= 468 = \text{\texttt{0x1D4}}$
    \item Fracción $= 0,75 \times 16 = 12 = \text{\texttt{0xC}}$
    \item $\mathbf{\text{USART1->BRR} = \text{\texttt{0x1D4C}}}$
\end{itemize}

\textbf{Ejemplo 2: 115200 bps con USART1 en APB2 (72 MHz):}
$$\text{USARTDIV} = \frac{72.000.000}{16 \times 115200} = 39,0625$$
\begin{itemize}
    \item Mantisa $= 39 = \text{\texttt{0x027}}$
    \item Fracción $= 0,0625 \times 16 = 1 = \text{\texttt{0x1}}$
    \item $\mathbf{\text{USART1->BRR} = \text{\texttt{0x0271}}}$
\end{itemize}
\end{formulabox}
\end{conceptbox}

\subsection{Gran Cuadro Comparativo de Protocolos Serie: SPI vs I2C vs UART}
\begin{center}
\small
\begin{tabularx}{\textwidth}{@{}p{3.0cm}XXX@{}}
\toprule
\textbf{Parámetro} & \textbf{SPI} & \textbf{I2C} & \textbf{UART / USART} \\
\midrule
\textbf{Tipo de Sincronismo} & Síncrono (SCK explícito) & Síncrono (SCL explícito) & Asíncrono (acuerdo de baud rate) \\
\rowcolor{hdrgray} \textbf{Líneas Físicas} & 4 (MOSI, MISO, SCK, CS) & 2 (SDA, SCL) & 2 (TX, RX) \\
\textbf{Modo de Transmisión} & Full-Duplex & Half-Duplex & Full-Duplex \\
\rowcolor{hdrgray} \textbf{Topología} & Maestro-Esclavo (Punto a Punto o Estrella con CS) & Multimaestro / Multiesclavo (Bus compartido) & Punto a Punto (1 a 1) \\
\textbf{Direccionamiento} & Físico por hardware (línea CS) & Por software (7 o 10 bits en trama) & Sin direccionamiento de bus \\
\rowcolor{hdrgray} \textbf{Nivel Eléctrico} & Push-Pull (3.3V / 5V) & Open-Drain con Pull-Up externo & TTL (0-3.3V) o RS-232 ($\pm 9$V) \\
\textbf{Velocidad Típica} & 10 a 50+ Mbps (Muy alta) & 100 kbps, 400 kbps, hasta 3.4 Mbps & 9600 bps a 115200+ bps (Lenta) \\
\rowcolor{hdrgray} \textbf{Detección de Errores} & Ninguna por defecto en hardware & Bit de ACK/NACK en cada byte & Bit de Paridad opcional y flags FE/PE \\
\textbf{Ventaja Principal} & Máxima velocidad y simplicidad de hardware & Mínima cantidad de pines (solo 2 para decenas de sensores) & Universal en PCs, terminales y enlaces de larga distancia \\
\rowcolor{hdrgray} \textbf{Desventaja Principal} & Requiere muchos pines a medida que crecen los esclavos & Más lento, sensible a capacitancia de bus y pull-ups & Sensible a diferencias de frecuencia de reloj entre nodos \\
\bottomrule
\end{tabularx}
\end{center}
"""
