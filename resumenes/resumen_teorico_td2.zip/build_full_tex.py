# -*- coding: utf-8 -*-
"""Script que genera el archivo LaTeX completo con todos los 9 modulos y lo compila."""

import m1_arquitectura
import m2_cortex_m3
import m3_toolchain
import m4_nvic
import m5_perifericos_serie
import m6_freertos
import m7_preguntas
import m8_ejercicios_libros
import m9_solucionario_libros

header = r'''\documentclass[9pt,a4paper]{extarticle}

% --- Geometria y Margenes ---
\usepackage[left=18mm, right=18mm, top=22mm, bottom=22mm, headheight=14pt]{geometry}

% --- Idioma y Tipografia ---
\usepackage[spanish,es-tabla]{babel}
\usepackage[T1]{fontenc}
\usepackage{lmodern}
\usepackage{microtype}
\renewcommand{\familydefault}{\sfdefault}

% --- Matematicas ---
\usepackage{amsmath, amssymb, mathtools}

% --- Tablas ---
\usepackage{booktabs}
\usepackage{tabularx}
\usepackage{array}
\usepackage{colortbl}

% --- Colores (Monocromatico / Escala de grises para Ahorro de Tinta) ---
\usepackage[table,xcdraw]{xcolor}
\definecolor{secblack}{gray}{0.0}
\definecolor{subgray}{gray}{0.25}
\definecolor{linegray}{gray}{0.65}
\definecolor{hdrgray}{gray}{0.92}

% --- Cajas tcolorbox (Fondos blancos segun regla de ahorro de tinta) ---
\usepackage{tcolorbox}
\tcbuselibrary{skins, breakable}

\newtcolorbox{conceptbox}[1]{
  colback=white,
  colframe=black!75,
  fonttitle=\bfseries\small,
  title={\textsf{#1}},
  boxrule=0.6pt,
  arc=2pt,
  left=4pt, right=4pt, top=3pt, bottom=3pt,
  before skip=4pt, after skip=4pt,
  breakable
}

\newtcolorbox{formulabox}[1]{
  colback=white,
  colframe=black!55,
  fonttitle=\bfseries\small,
  title={\textsf{#1}},
  boxrule=0.6pt,
  arc=2pt,
  left=4pt, right=4pt, top=3pt, bottom=3pt,
  before skip=4pt, after skip=4pt,
  breakable
}

\newtcolorbox{examqbox}[1]{
  colback=white,
  colframe=black!85,
  fonttitle=\bfseries\small,
  title={\textsf{#1}},
  boxrule=0.75pt,
  arc=2pt,
  left=4pt, right=4pt, top=3pt, bottom=3pt,
  before skip=5pt, after skip=5pt,
  breakable
}

\newtcolorbox{warnbox}[1]{
  colback=white,
  colframe=black!90,
  fonttitle=\bfseries\small,
  title={\textsf{!! ATENCION: #1}},
  boxrule=0.8pt,
  arc=2pt,
  left=4pt, right=4pt, top=3pt, bottom=3pt,
  before skip=4pt, after skip=4pt,
  breakable
}

% --- Codigo Fuente (Listings) ---
\usepackage{listings}
\lstset{
  language=C,
  basicstyle=\ttfamily\footnotesize,
  keywordstyle=\bfseries\color{black},
  commentstyle=\itshape\color{gray},
  stringstyle=\color{black},
  backgroundcolor=\color{white},
  frame=single,
  rulecolor=\color{black!30},
  breaklines=true,
  columns=fullflexible,
  keepspaces=true,
  tabsize=2,
  xleftmargin=3pt,
  xrightmargin=3pt,
  aboveskip=3pt,
  belowskip=3pt,
  morekeywords={uint8_t,uint16_t,uint32_t,int8_t,int16_t,int32_t,volatile,void,TickType_t,BaseType_t,TaskHandle_t,QueueHandle_t,SemaphoreHandle_t,portBASE_TYPE},
  literate={->}{{$\rightarrow$}}1 {>=}{{$\geq$}}1 {<=}{{$\leq$}}1 {!=}{{$\neq$}}1
}

% --- Formato de Titulos ---
\usepackage{titlesec}
\titleformat{\section}{\large\bfseries\color{secblack}}{\thesection}{0.5em}{}[\titlerule]
\titleformat{\subsection}{\normalsize\bfseries\color{subgray}}{\thesubsection}{0.4em}{}
\titleformat{\subsubsection}{\small\bfseries\color{black}}{\thesubsubsection}{0.3em}{}
\titlespacing*{\section}{0pt}{8pt}{4pt}
\titlespacing*{\subsection}{0pt}{6pt}{2pt}
\titlespacing*{\subsubsection}{0pt}{4pt}{1pt}

% --- Encabezados y Pies de Pagina ---
\usepackage{fancyhdr}
\pagestyle{fancy}
\fancyhf{}
\fancyhead[L]{\scriptsize\textsf{TÉCNICAS DIGITALES II --- COMPENDIO TEÓRICO COMPLETO}}
\fancyhead[R]{\scriptsize\textsf{UTN FRC --- 2026}}
\fancyfoot[L]{\scriptsize\textsf{STM32F103C8T6 (ARM Cortex-M3 @ 72 MHz) \& FreeRTOS Kernel}}
\fancyfoot[R]{\small\thepage}
\renewcommand{\headrulewidth}{0.3pt}
\renewcommand{\footrulewidth}{0.3pt}

% --- Listas compactas ---
\usepackage{enumitem}
\setlist{nosep, leftmargin=*, topsep=2pt, parsep=1pt, itemsep=1pt}

% --- Hiperlinks ---
\usepackage[hidelinks,pdfusetitle]{hyperref}

% ======================================================================
\begin{document}
\shorthandoff{"}

% --- Portada / Cabecera ---
\begin{center}
{\LARGE\bfseries\textsf{COMPENDIO TEÓRICO COMPLETO}}\\[1.5mm]
{\Large\bfseries\textsf{TÉCNICAS DIGITALES II --- 1ER PARCIAL TEÓRICO}}\\[1.5mm]
{\small\textsf{Universidad Tecnológica Nacional --- Facultad Regional Córdoba --- Cátedra: Dr. Ing. Steiner Guillermo}}\\[1mm]
{\footnotesize\textsf{Hardware: STM32F103C8T6 (ARM Cortex-M3 @ 72 MHz, 64 KB Flash, 20 KB SRAM) $\cdot$ Toolchain: GNU GCC $\cdot$ Kernel: FreeRTOS v10.x}}\\[1.5mm]
\rule{\textwidth}{0.8pt}
\end{center}
\vspace{-2mm}

% --- Tabla de Contenidos ---
\begin{small}
\tableofcontents
\end{small}
\vspace{3mm}
\hrule
\vspace{4mm}
'''

footer = r'''
% ======================================================================
\end{document}
'''

full_tex = header + "\n" + \
           m1_arquitectura.content + "\n" + \
           m2_cortex_m3.content + "\n" + \
           m3_toolchain.content + "\n" + \
           m4_nvic.content + "\n" + \
           m5_perifericos_serie.content + "\n" + \
           m6_freertos.content + "\n" + \
           m7_preguntas.content + "\n" + \
           m8_ejercicios_libros.content + "\n" + \
           m9_solucionario_libros.content + "\n" + \
           footer

with open('/tmp/resumen_teorico_td2/resumen_teorico_td2.tex', 'w', encoding='utf-8') as f:
    f.write(full_tex)

print("Generated /tmp/resumen_teorico_td2/resumen_teorico_td2.tex successfully with M1 to M9.")
